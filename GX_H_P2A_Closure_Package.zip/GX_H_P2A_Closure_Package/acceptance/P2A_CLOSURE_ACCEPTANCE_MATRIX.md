# P2A Closure Acceptance Matrix

| ID | 场景 | 通过标准 |
|---|---|---|
| U01 | 官方 Turn receipt | 精确结算一次 |
| U02 | 自然中断无 receipt | 宽限期前保持待对账 |
| U03 | 宽限期到期 | 由产品维护路径产生不可变 ESTIMATED event |
| U04 | 估算后 receipt 迟到 | 追加幂等 adjustment，保留估算历史 |
| U05 | 重复/乱序 receipt | 不重复扣费或释放 |
| U06 | Parent/Child cumulative | 不重复计入 |
| U07 | Child 915 / Turn receipts 732 | 183 保留为 unattributed，除非有归属证据 |
| U08 | GX 重启跨 grace deadline | 自动维护一次结算 |
| T01 | 2 核 Deterministic Profile | 容量结果固定 |
| T02 | 宿主存在 CLAUDE_* | 子进程隔离后 Client Detection 确定 |
| T03 | 原 465 项 | 42 项逐项 adjudicate |
| DB01 | 慢事务定位 | 慢样本有 owner/operation |
| DB02 | 锁等待与事务 body 分离 | 可定位真实耗时 |
| AC01 | 一条命令跑 Phase 2A | 命令、日志、退出码、摘要完整 |
| AC02 | 证据归档 | SHA 校验通过，可解包 |
| AC03 | 历史保留 | 新 run 不覆盖旧失败记录 |
| IDLE01 | 连续空闲 | 退避有上限、无 busy-spin |
| IDLE02 | 空闲时新事件 | 及时唤醒并重置退避 |
| IDLE03 | Job/Usage deadline | 不晚于最近必要维护时间唤醒 |
| REG01 | 原 Phase 2A | 所有已通过测试回归通过 |

报告标签：PROVIDER_CONFIRMED / ESTIMATED / UNRESOLVED / UNATTRIBUTED_DELTA；证据标签：SCRIPTED / OFFICIAL_HOST_LOOPBACK / LIVE_MODEL / REAL_COMPUTE / INDEPENDENT_REVIEW。
