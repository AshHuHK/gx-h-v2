# P2A Closure + Test Infrastructure 蓝图

## 原则
保留已通过的 2A Engine/Driver 分支推进和跨进程恢复行为。每项改动对应已知问题和回归测试。不扩展到 Phase 2B。

## 1. Usage reconciliation
将计量事实区分为：
- `PROVIDER_CONFIRMED`：官方凭据可归属。
- `ESTIMATED`：宽限期结束仍无官方回执，按保守策略估算。
- `UNRESOLVED`：依据不足或归属冲突。
- `UNATTRIBUTED_DELTA`：已观察到增量但不能可靠归属某个 Turn。

Thread cumulative 是 Thread 级累计观察，不是单个 Turn 消费量。Turn receipt 才能直接归属 Turn。Turn delta 仅在可靠相邻快照和归属边界下计算。Parent/Child Thread 分开累计，不得重复计入。

自然中断后进入待回执状态。宽限期由产品自身维护/对账路径驱动；宽限期前不得提前估算结算。宽限期结束仍无回执，追加不可变 ESTIMATED 事件。迟到官方回执追加幂等 adjustment，引用原估算事件，不能覆盖历史。重复/乱序 receipt、GX 重启、维护任务重复运行均不得重复结算。

预算控制可使用保守估算，但成本报告必须分开 confirmed、estimated、unresolved 和 unattributed。不能把估算冒充官方真实用量，也不能随意释放预留差额。

关键案例：Child Thread cumulative=915，Turn receipts 合计=732，差额 183 不得塞进某个 Turn；在没有归属依据前保留为 UNATTRIBUTED_DELTA。实际实现前先审计 provider 的累计语义，不可盲目照抄示例数字。

## 2. 测试环境隔离
提供 Deterministic Test Profile：固定 CPU/Job capacity、并发上限和 GPU availability，不依赖宿主核数；不改变生产默认容量。
保留 Real Resource Profile 测真实准入，两类结果分开报告。
测试子进程使用环境变量白名单，清除宿主 `CLAUDE_*` 标记（除非该测试专门验证 Client Detection），固定 Codex/Client Detection 配置；不修改用户 Shell。
原 465 项测试在固定环境复跑，42 项逐项归类为 environment / fixture defect / regression / unresolved。不能直接 skip 或批量 xfail。

## 3. SQLite Transaction Telemetry
为现有写事务加显式 `transaction_owner`、`operation`、`run_id`、`duration_ms`、`lock_wait_ms`、`commit_or_rollback`、`rows_changed` 标签。至少覆盖 Engine、Reactor、Driver/Outbox/Usage、JobService、Root Delivery。
分开统计 lock wait 与 transaction body。用轻量聚合/采样，不增加常驻线程，不在事务内做额外 IO，不记录 Prompt、Artifact 内容或凭据。标签从事务入口传入，不用脆弱的 stack introspection 猜来源。

## 4. Acceptance Automation
增加统一命令入口，遵循仓库 CLI 风格，例如 `gx-acceptance run phase2a`、`gx-acceptance run all`、`gx-acceptance report <run-id>`。
自动记录 Git SHA/dirty state、OS/Python/SQLite、精确命令/退出码、测试分类、日志、DB snapshot、事件轨迹、SHA-256 manifest。大型证据压缩归档，Git 保留摘要/索引/manifest/失败复现材料。新 run 不覆盖旧失败记录；支持全量和仅重跑失败项。严格区分 SCRIPTED、OFFICIAL_HOST_LOOPBACK、LIVE_MODEL、REAL_COMPUTE、INDEPENDENT_REVIEW。

## 5. Driver idle backoff
无 ready work、无 Outbox、无到期 Job/Usage maintenance、无 Codex dispatch 时逐步退避并设上限。新事件/Job 通知/外部唤醒立即打断并重置。下一次 wakeup 必须考虑最近 Job poll、Usage grace deadline、Lease maintenance。不得延迟 signal/shutdown，不新增每 Run 常驻轮询线程。

## 6. 不做
不改 Engine Ready Node 语义；不实现动态 Graph；不实现 Worker Runtime；不做 Slurm adapter；不跑昂贵付费模型对照。
