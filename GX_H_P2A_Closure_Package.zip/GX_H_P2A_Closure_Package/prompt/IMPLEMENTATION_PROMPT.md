# Agent Prompt — GX-H P2A Closure + Test Infrastructure

你是 GX-H Principal Engineer。本次只完成 P2A Closure，不进入 Phase 2B。

## Baseline
Repo `AshHuHK/gx-h-v2`, branch `v3.2-p2`。
参考产品冻结 `c15eada9611f60519bafbb3366c908629dbea157`；参考验收 HEAD `78a8b07766376d93a458e5175c41f1f327ff8f36`。
先执行 `git status --short`、`git branch --show-current`、`git rev-parse HEAD`、`git log --oneline -20`。若 HEAD 前进，在当前 HEAD 增量工作；不得 reset/force push/覆盖用户改动。

## Hard scope
禁止 GraphVersion/NodeAttempt/Dynamic Graph/CAS/Decision Lease/exec_key/Seed reuse/Slurm production adapter/Checkpoint/Plugin Worker Runtime/独立 Plugin/Research Intelligence。不得重写已通过的 Engine 分支推进逻辑。不得重跑昂贵的 13 波付费模型对照。不得把估算标成官方真实 Token。

## Phase 0 — Source audit (no edits)
检查：Turn receipt、Thread cumulative、Parent/Child usage、HELD reservation、maintenance/probe 调度、Driver loop、测试 capacity、Client Detection 与 CLAUDE_*、SQLite transaction wrapper、acceptance runner/归档、idle loop/wakeup。
产出 `P2A_CLOSURE_SOURCE_AUDIT.md`，给出调用链、文件行号、事务边界，标 existing/partial/missing/bug。不要只靠 grep。

## Phase 1 — Usage
实现 PROVIDER_CONFIRMED / ESTIMATED / UNRESOLVED / UNATTRIBUTED_DELTA。
Thread cumulative 不得直接当 Turn usage；Parent/Child 分开。官方可归属 Turn receipt 精确结算。缺 receipt 时等待配置宽限期，由产品维护路径自动驱动。到期后追加不可变 ESTIMATED event；迟到 receipt 追加幂等 adjustment，保留估算历史。重复/乱序 receipt、重启、维护任务重复不得重复结算。
重点复核 Child cumulative=915、Turn receipts=732、差额=183：不得重复计费或把 915 记给单一 Turn。先验证 provider cumulative 语义。
预算控制可以用保守估算；成本报告必须区分真实、估算、未归属。未知值不足以估算时保持 UNRESOLVED。

## Phase 2 — Test isolation
实现固定 Deterministic Test Profile，不依赖宿主核数；保留 Real Resource Profile。测试子进程用环境变量白名单，隔离 CLAUDE_*，不改用户 Shell。固定环境重跑原 465 项，对原 42 项逐项归类：environment / fixture / regression / unresolved。不得直接 skip/xfail 掩盖。

## Phase 3 — SQLite telemetry
给 Engine、Reactor、Driver/Outbox/Usage、JobService、Root Delivery 的事务加显式 owner/operation 标签。分开 lock wait 与 transaction body，输出 p50/p95/max 和慢事务样本。轻量采样/聚合；不在事务内增加 IO，不记录敏感数据。

## Phase 4 — Acceptance automation
实现统一 CLI（命令形式遵循现有项目）。记录 SHA/dirty state/环境、命令/退出码、分类、日志、DB snapshot、事件轨迹、SHA manifest。大型证据压缩归档；保留历史 run；支持全量和失败项重跑。报告不可把 Scripted 冒充 Live Model/Real Compute。

## Phase 5 — Idle backoff
无工作时指数退避、有上限；新事件立即唤醒；把 Job/Usage/Lease deadline 纳入 wakeup；shutdown/signal 可及时中断；不新增每 Run 常驻线程。

## Deliverables
- `P2A_CLOSURE_SOURCE_AUDIT.md`
- `P2A_09_USAGE_RECONCILIATION_REPORT.md`
- `P2A_TEST_ENVIRONMENT_REPORT.md`
- `P2A_SQLITE_TRANSACTION_TELEMETRY_REPORT.md`
- `P2A_ACCEPTANCE_AUTOMATION_REPORT.md`
- `P2A_IDLE_BACKOFF_REPORT.md`
- `P2A_CLOSURE_ACCEPTANCE_REPORT.md`
- `P2A_CLOSURE_LIMITATIONS.md`
- 原始证据归档与 SHA-256 manifest

## Done
官方 receipt 精确结算；无 receipt 宽限期前不估算、宽限期后 ESTIMATED；迟到 receipt 幂等调整且保留历史；Parent/Child 不重复；915/732/183 案例正确；产品维护路径自动触发；465 项逐项归类；事务慢样本可定位 owner/operation；一条命令重跑并归档；idle backoff 不错过 deadline；原 Phase 2A 全回归通过。否则 PARTIAL/BLOCKED。
