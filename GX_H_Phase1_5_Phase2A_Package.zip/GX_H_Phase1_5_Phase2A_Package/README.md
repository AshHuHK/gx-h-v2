# GX-H Phase 1.5 + Phase 2A Package

基线：v3.2-p2 / 51e0e135。此包只要求 Phase 1.5 架构增补和 Phase 2A 静态 Workflow 持久运行证明；不实现动态 Graph、GraphVersion、NodeAttempt 新表、远程 Slurm、Checkpoint、Plugin Worker Runtime 或独立科研 Plugin。
