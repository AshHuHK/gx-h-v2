# Phase 1.5 Decision Checklist

- [ ] P2 path must not require science_grid@3-specific branching; implementation generalized later in 2D.
- [ ] Plugin Node isolation decision recorded; Worker Runtime deferred beyond 2A.
- [ ] Backend capabilities explicit.
- [ ] attempt_id / operation_id / scheduler_job_id distinct.
- [ ] OUTCOME_UNKNOWN and operator resolution path defined.
- [ ] SQLite precompute vs transaction recheck boundary defined.
- [ ] Decision Lease uses existing Lease owner; scope/renewal/revocation defined.
- [ ] Strict single-head CAS retained; conflict metrics defined.
- [ ] Bootstrap persistence invariant defined without forced fake Workflow.
- [ ] Phase 2A non-goals explicit.
- [ ] Six ADRs cross-consistent.
