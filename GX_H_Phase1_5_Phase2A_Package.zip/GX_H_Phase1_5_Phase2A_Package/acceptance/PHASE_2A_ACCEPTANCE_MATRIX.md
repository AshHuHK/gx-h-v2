# Phase 2A Acceptance Matrix

| ID | Scenario | Required proof | Evidence class |
|---|---|---|---|
| P2A-01 | Same Run: A waits Codex, B has completed Job + ready deterministic nodes | B completes while A stays waiting | SCRIPTED + Engine integration |
| P2A-02 | A waits Codex, B waits Job, C ready | C completes | SCRIPTED |
| P2A-03 | Stop all Codex/App Server processes | GX progresses deterministic work and reconciles Jobs; no spawn | Cross-process |
| P2A-04 | Kill GX during mixed branch state | New process restores same DB/state | Cross-process |
| P2A-05 | Pending usage + Job completion + deterministic transition + Codex unavailable | No early return blocks work; usage retained | SCRIPTED |
| P2A-06 | Completed node after restart | No duplicate execution/Artifact/settlement | Cross-process |
| P2A-07 | Waiting node after restart | Wait owner/reason/reference retained | Cross-process |
| P2A-08 | Independent branch failure | Only dependent descendants blocked | SCRIPTED |
| P2A-09 | v3.1 terminal protocol regression | Existing suite passes | Regression |
| P2A-10 | Same-Attempt Schema repair | Existing suite passes | Regression |
| P2A-11 | Native Child scope/recovery/usage | Official host trace | OFFICIAL_HOST_LOOPBACK |
| P2A-12 | Brief Preloading digest/size/freshness | Existing suite passes | SCRIPTED |
| P2A-13 | science_grid@3 and historical Run cold resume | Compatible state | Regression |
| P2A-14 | Driver idle | No busy-spin; bounded CPU/wakeup | SCRIPTED |
| P2A-15 | Job backend temporarily unavailable | Defer reconcile; no duplicate submit | SCRIPTED |

Measure ready scan, Driver cycle, Job reconciliation, SQLite Writer p50/p95, ready/parked counts, deterministic completions with Codex absent, idle CPU/wakeup, duplicate node/Artifact/settlement count.

No paid model run required. Do not conflate SCRIPTED, OFFICIAL_HOST_LOOPBACK and LIVE_MODEL.
