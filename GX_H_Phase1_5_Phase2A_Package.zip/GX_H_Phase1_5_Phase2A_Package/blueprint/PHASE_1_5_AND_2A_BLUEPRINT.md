# GX-H Phase 1.5 + Phase 2A Blueprint

Baseline: `AshHuHK/gx-h-v2`, branch `v3.2-p2`, expected HEAD `51e0e13583d95e9cad1386e1d4c77324977e97ea`. If actual HEAD differs, record and re-audit; never reset or overwrite user work.

## Goal
First prove GX is the persistent execution owner: a Run continues deterministic work and reconciles Jobs while Codex/App Server is absent. Do not implement dynamic Graph in this phase.

## Phase 1.5 — concise ADR delta
Update existing `V32_ADR_DECISIONS.md` and ADR-01..06; add only `V32_PHASE_1_5_DELTA.md`.

1. **Generic research protocol:** future P2 paths must not require `science_grid@3` branches for Terminal Submission, Task Brief/Artifact Preloading, Role Tool Catalog or Product/Evidence delivery. Keep old Grid compatibility. Full generalization is deferred to Phase 2D.
2. **Plugin Node isolation:** trusted in-process Python is not a security sandbox. Future third-party Node Handlers must not execute inside GX durable loop or SQLite Writer transaction. Target: bounded Worker Process for ordinary plugin nodes; existing Job Runtime for heavy CPU/GPU/HPC. Record now; do not implement Worker Runtime in 2A.
3. **Backend semantics:** distinguish `attempt_id` (GX execution), `operation_id` (external submit operation), `scheduler_job_id` (backend identity). Backend declares idempotent submit, lookup by stable identity, authoritative proof of not-submitted, cancel and checkpoint support. Unknown outcome remains `OUTCOME_UNKNOWN`; after policy window, route to operator resolution. Do not blindly resubmit. Record now; implementation deferred to 2C.
4. **SQLite transactions:** precompute pure/large work outside Writer transaction (graph/schema normalization, hashes, dependency/impact calculation, large parsing, file writes). Inside transaction recheck current state/version/lease/authorization/budget/idempotency and perform minimal conditional writes/Outbox. Never weaken consistency to reduce latency.
5. **Decision Lease:** reuse existing Lease owner/table; do not create another Lease Manager. Define Run+decision scope, owner/session, base version (when GraphVersion exists), expiry, renewal, revocation, same-scope uniqueness and commit-time recheck. Full implementation deferred to 2B.
6. **Scope CAS:** retain strict single Run head CAS initially; no multi-head/auto-merge. Later record conflict rate, re-proposal count, token/time cost and actual scope overlap.
7. **Bootstrap:** no mandatory fake scientific Workflow and no forced new Run state machine. Before first GraphVersion, Goal, hard budget, plugin composition and initialization authorization must be durable. Use the lowest-risk existing representation.

## Phase 2A — GX persistent execution proof

### Engine
Replace “take first remaining node” with scanning all nodes and selecting any currently ready node. A node waiting for Codex/Job/Human only parks its node/branch. Continue independent ready nodes. Run parks only when no node is runnable and all branches are waiting or terminal. Do not build a general new DAG engine; support the current static Workflow model.

### Driver
Order each durable cycle:
1. durable events / Outbox;
2. reconcile already-submitted Jobs;
3. deterministic Workflow transitions;
4. ready Artifact/Measurement/settlement work;
5. identify work truly requiring Codex;
6. dispatch Codex only if available.

If Codex/App Server is unavailable, persist a waiting reason/backoff/notification for the affected scope. Do not exit the whole Driver, do not silently restart Codex to pass tests, and do not lose pending usage reconciliation. Unrelated branches continue.

### Wait semantics
Reuse existing enums where possible. Distinguish at least `WAITING_JOB`, `WAITING_DECISION`, `WAITING_AGENT_TASK`, `WAITING_HUMAN`, `READY`, `RUNNING`, terminal. Each wait has owner/reference, reason, timestamp and next retry where applicable. Avoid unnecessary schema.

### Recovery
After GX process restart, restore same Run/branch/node/Job state. Completed nodes are not repeated; waiting nodes are not advanced; unknown Job state is not blindly resubmitted.

## Required tests
- A01: same Run, Branch A waits for Codex; Branch B has completed Job and deterministic downstream nodes. Stop all Codex/App Server processes. GX must complete B, keep A waiting, and must not spawn Codex.
- A14: A waits Codex, B waits Job, C is deterministic and ready. C completes.
- Cross-process restart during mixed state: kill GX, start new process on same DB; state consistent, no duplicate execution.
- Driver ordering: pending usage + Job completion + deterministic transition + Codex unavailable coexist; deterministic work and Job reconciliation proceed without losing usage accounting.
- Full v3.1 regressions: terminal protocol, same-Attempt repair, product idempotency, Native Child scope/recovery/usage, Brief Preloading, science_grid@3 and historical Run cold resume.

## Observability
Measure ready-node scan, Driver cycle, Job reconciliation, SQLite Writer p50/p95, ready/parked branch counts, deterministic completions while Codex absent, idle CPU/wakeup, duplicate node/Artifact/settlement count. Use scripted/official-host-loopback only; no paid model performance contest in 2A.

## Explicit non-goals
No graph_versions/node_attempts tables, GraphVersion/CAS/Amendment, plan_key/exec_key/seed reuse, full Decision Lease implementation, remote Slurm adapter, production operation_id backend, checkpoint continuation, Plugin Node Worker Runtime, independent scientific Plugin or Research Intelligence.

## Definition of Done
Same Run can wait on one branch while another progresses; GX reconciles Jobs and deterministic work with Codex/App Server stopped; Codex absence does not terminate Driver; A01/A14 and cross-process restart have inspectable state/event evidence; v3.1 regression passes; no duplicate Scheduler/Workflow Engine/Job Manager; no Phase 2B/2C/2D/3 work smuggled into 2A.
