# Coding Agent Prompt — GX-H Phase 1.5 + Phase 2A

You are the Principal Engineer. Work only on Phase 1.5 architecture delta and Phase 2A persistent-execution proof.

## Baseline
Repository: `AshHuHK/gx-h-v2`
Branch: `v3.2-p2`
Expected HEAD: `51e0e13583d95e9cad1386e1d4c77324977e97ea`

First run:
```bash
git status --short
git branch --show-current
git rev-parse HEAD
git log --oneline -15
```
If HEAD differs, record actual state and re-audit. Never reset, force-push or discard user work.

## Mission
1. Phase 1.5: update existing `V32_ADR_DECISIONS.md` and ADR-01..06; add `V32_PHASE_1_5_DELTA.md`.
2. Phase 2A: only modify existing static Workflow Engine/Driver to prove GX progresses deterministic work and reconciles Jobs while Codex/App Server is unavailable.

## Hard exclusions
Do NOT implement graph_versions/node_attempts tables, dynamic Graph/GraphVersion/CAS/Amendment, plan_key/exec_key/seed reuse, full Decision Lease, remote Slurm adapter, production operation_id backend, checkpoint continuation, Plugin Node Worker Runtime, independent Plugin or Research Intelligence.

## Phase 0 — Source map, no code changes
Inspect:
- `gx-h/gx_core/orchestration/engine.py`
- `gx-h/gx_core/p0/driver.py`
- `gx-h/gx_core/p0/coordinator.py`
- `gx-h/gx_core/p0/roots.py`
- `gx-h/gx_core/p0/root_delivery.py`
- `gx-h/gx_core/jobs/`, `teams/`
- current Run/Workflow/Node/Outbox/Lease schema and migrations
- `V32_SOURCE_AUDIT.md`, `V32_ADR_DECISIONS.md`, six ADRs
- v3.1 terminal/repair/native-child/Brief regression tests

Produce `PHASE_2A_SOURCE_MAP.md`, tracing:
1. first-remaining-node selection;
2. `_park` and whole-Run effects;
3. Driver order: pending usage, Job reconciliation, deterministic transitions, Codex dispatch;
4. Codex/App Server unavailable exception path;
5. Job polling vs duplicate submission;
6. nodes executable without Codex;
7. reusable existing states/APIs;
8. smallest change set and rollback.

Do not rely on grep alone; trace call paths and transaction boundaries.

## Phase 1 — Phase 1.5 delta
Update existing ADR decisions and ADR-01..06; add `V32_PHASE_1_5_DELTA.md`. Record:
- P2 generic path must not require science_grid@3 branches; full generalization deferred to 2D.
- future Plugin Node isolation; do not implement Worker Runtime in 2A.
- backend capability declarations; distinct attempt_id / operation_id / scheduler_job_id; OUTCOME_UNKNOWN and operator resolution.
- precompute outside SQLite Writer; recheck mutable state inside transaction.
- Decision Lease scope/renewal/revocation using existing Lease owner; full implementation deferred to 2B.
- strict single-head CAS; record conflict metrics later.
- Bootstrap persistence invariant without forcing fake Workflow/new state machine.

No new large architecture document.

## Phase 2A — implementation
**Engine:** scan all remaining nodes and select any ready node. A waiting node/branch cannot block independent ready nodes. Only park whole Run when nothing can progress. Do not implement a new general DAG engine.

**Driver:** process durable events/Outbox, reconcile already-submitted Jobs, advance deterministic transitions and settlements first. Only then dispatch Codex. Codex/App Server unavailable must persist scoped waiting/backoff/notification and not exit Driver. Do not auto-start Codex during shutdown test. Preserve pending usage accounting.

**Wait semantics:** reuse existing states where possible; distinguish Job, Decision, Agent Task and Human waits. Persist owner/reference/reason/time/next retry as applicable.

**Recovery:** GX restart restores branch/node/Job state; no repeated completed node; no accidental advance of waiting node; no blind Job resubmit.

## Required tests
1. A01 same Run, Branch A WAITING_DECISION, Branch B has completed Job + deterministic downstream. Stop all Codex/App Server. GX completes B, A remains waiting, zero Codex spawn.
2. A14 A waits Codex, B waits Job, C ready deterministic; C completes.
3. Kill GX during mixed state; new process uses same DB; state and Outbox reconcile; no duplicate execution.
4. Inject pending usage + Job completion + deterministic transition + Codex unavailable; deterministic work and Job reconciliation still proceed; usage is not lost.
5. Full v3.1 regressions: terminal submission/interrupt/ACK, same-Attempt repair, idempotency, Native Child scope/recovery/usage, Brief Preloading, science_grid@3 and historical Run cold resume.
6. Job status temporarily unavailable: defer reconciliation, no duplicate submit.
7. Idle Driver: no busy-spin; bounded wakeups.

## Evidence
Every test records commit SHA, dirty state, exact command/exit code, test name, Run/branch/node/Job IDs, event timeline, before/after DB state, whether Codex was spawned, duplicate count and evidence path. Label SCRIPTED / OFFICIAL_HOST_LOOPBACK / LIVE_MODEL honestly.

## Performance
No paid-model benchmark in 2A. Measure ready scan, Driver cycle, Job reconciliation, SQLite Writer p50/p95, ready/parked counts, deterministic completions while Codex absent, idle CPU/wakeup. Do not weaken Lease/budget/state checks.

## Required outputs
- `PHASE_2A_SOURCE_MAP.md`
- `V32_PHASE_1_5_DELTA.md`
- updated `V32_ADR_DECISIONS.md` and ADR-01..06
- minimal Phase 2A code
- `PHASE_2A_IMPLEMENTATION_REPORT.md`
- `PHASE_2A_ACCEPTANCE_REPORT.md`
- `PHASE_2A_ROLLBACK_REPORT.md`
- `PHASE_2A_LIMITATIONS.md`
- raw logs, DB snapshots and event traces

## Done only if
A waiting branch does not block independent ready work; GX advances deterministic work and reconciles Jobs with Codex/App Server stopped; Codex absence does not terminate Driver; A01/A14 and cross-process restart have evidence; v3.1 regression passes; no duplicate execution engine; no Phase 2B/2C/2D/3 scope creep. Otherwise report PARTIAL/BLOCKED.
