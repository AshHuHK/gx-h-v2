# GX-H v3.1 — Execution Efficiency & Scientific Delivery Protocol
## Revised implementation blueprint (source-aligned)

**Target:** `AshHuHK/gx-h-v2`, current `v3` branch.  
**Reference runtime:** inspect and pin the exact checked-out Codex/App Server version; prior evidence refers to 0.169.0.  
**Purpose:** reduce avoidable model requests and repeated context while preserving GX transaction, fencing, usage accounting, evidence provenance and scientific validity.

This is an implementation specification, not evidence that any change has been implemented or tested.

---

# 0. Final decisions

The core rule is:

> GX performs deterministic control, binding, validation, accounting and termination. Plugin/workflow code supplies domain contracts and deterministic evaluators. Codex spends requests on work that genuinely requires model reasoning.

This revision incorporates the source-based corrections:

1. **A:** After an accepted or terminally rejected submission, GX does not write a Dynamic Tool Response. It completes the Goal and interrupts the Turn; Codex 0.169's pending-server-request abort path should close the unanswered tool call. A bounded timeout fallback may write a response only if interruption is confirmed not to have taken effect. This must be proven against the exact runtime before enabling.
2. **B:** ProductContract supports a per-authorized-path map. The model supplies only model-authored fields; GX adds deterministic fields and Evaluator adds computed fields per path. Semantic checks are executable, versioned workflow functions, not descriptive strings.
3. **Versioning:** B1 changes the graph/validator semantics, so implement `science_grid@3` once in B1. Do not mutate `science_grid@2`; B4 must not create another `@3`.
4. **C:** Reuse `SchemaInvalid` and transaction rollback. Persist repair counters/failure dedupe in a separate small transaction after rollback. Do not add a five-state submission machine.
5. **D:** No new generic Context Snapshot or freshness subsystem. Inject the small immutable referenced Artifacts into the existing Task Brief (within measured limits), remove duplicate `gx_task_context` calls. Existing Artifact refs/digests and `brief_sha256` remain authoritative. Intent and supplemental-source updates continue through existing notification paths.
6. **E:** Tool availability is decided by role semantics, then verified against actual call logs. A Reviewer of frozen evidence should not receive Job-creation tools merely because a short log sample did not show use.
7. **F:** Evaluator is part of the `science_grid@3` implementation. Preserve measurement-validity checks. Programmatic evaluation may replace only deterministic checks; independent review remains for genuine scientific judgment.
8. **H/B0:** Request classification is mechanical from response/tool events and workflow phase, not subjective labels such as Research vs Execution. Existing turn-total token receipts do not provide per-request input tokens; first add per-response usage telemetry, then run a small instrumented wave.
9. Reports are consolidated into four deliverables. No deployment/rollback report is required for a development branch unless a real deployment/migration is performed.

## Batches

| Batch | Scope |
|---|---|
| B0 | Audit + per-response usage telemetry + mechanical request classification + local protocol probe |
| B1 | A+B+C + `science_grid@3` + executable semantic validators + deterministic `supported` |
| B2 | E role-based tool profiles and Multi-Agent defaults; separate commit/measurement |
| B3 | D: inject small immutable Artifacts into existing Task Brief; remove duplicate context retrieval |
| B4 | Deferred: extract reusable Product/Evaluator API only when a second workflow needs it |
| B5 | Separate Scientific Intelligence quality benchmark |

No Work Unit, submission state machine, generic Context Snapshot, plugin Event Bus, or new Workflow Engine.

---

# 1. B0 — source audit, usage telemetry and protocol probe

## 1.1 Audit

Inspect actual branch/HEAD and current source. At minimum trace:
- dynamic tool handler return/write behavior in `hostobs/app_server_client.py`;
- App Server `client.send` and request paths;
- Goal update and Turn interrupt;
- Codex pending server request abort behavior;
- `roots.py` submission and receipt transaction;
- `SchemaInvalid` and rollback;
- Tool call receipt table;
- `teams/service.py` product validation and artifact publication;
- `p0/metering.py` response usage accounting;
- `science_grid_v2/nodes.py` per-path review schema and reviewer independence;
- Task Brief and `gx_task_context`;
- role tool profiles and actual tool registry;
- current 13-wave receipts.

Produce one concise source audit + baseline report, not a dozen overlapping reports.

## 1.2 Per-response usage telemetry

Existing receipts aggregate usage at Turn level. Do not pretend they can recover the first-request input tokens retrospectively.

Add telemetry for every completed model response using the response/completion event already received by GX:
- response ID;
- Thread/Turn/Root/Attempt/Run IDs;
- timestamp and request ordinal;
- input tokens;
- output tokens;
- cached input tokens;
- reasoning tokens, if provided;
- total tokens;
- provider/model;
- linked tool calls and outcome.

If a field is absent from the provider event, store null, not an inferred value. Preserve the existing Thread/Turn cumulative accounting as authoritative; per-response telemetry is attribution data and must not double-charge the budget ledger.

## 1.3 Mechanical request classification

Do not use subjective `RESEARCH` / `EXECUTION` labels as the primary baseline.

Classify each model response/request mechanically using the workflow phase and observable tool calls:
- `READ`: context/artifact/evidence retrieval only.
- `PRODUCE`: first product/artifact submission attempt.
- `REPAIR`: response follows a structural/schema validation failure.
- `POST_SUBMIT`: response occurs after accepted or terminally rejected submission.
- `OTHER_CONTROL`: other control/coordination-only action.
- `MIXED`: multiple classes in one response; preserve tool-event breakdown.
- `UNCLASSIFIED`: insufficient event evidence.

Do not infer the class from output prose. Keep classification rules versioned. Existing 369-request receipts can provide counts/phase associations where recorded, but cannot provide missing per-request tokens. Add telemetry, then run one small, capped instrumented wave to measure first-request and per-class token values.

## 1.4 A protocol probe — local scripted model first

The source review identifies the Codex 0.169 pending-request abort path:
- Turn interruption invokes pending server request abortion.
- The dynamic tool layer handles the resulting transition error without writing a normal tool response.
- The core cancels the pending dynamic tool call.

The intended GX behavior is therefore **no normal Dynamic Tool Response after terminal acceptance/rejection**.

Probe the exact pinned App Server with a local scripted model and controlled delays:
1. Start a Turn that invokes a GX dynamic tool and waits for the tool response.
2. GX commits accepted or terminally rejected state.
3. GX sends Goal Complete (where applicable).
4. GX sends Turn Interrupt.
5. GX deliberately does not write a Dynamic Tool Response.
6. Observe that Codex aborts the pending server request, the Turn terminates, and no subsequent model request starts.
7. Verify usage reconciliation and child-agent accounting.

Test both Accepted and terminal Rejected outcomes. Do not interrupt recoverable SchemaInvalid responses; those must return the validation error to the same Attempt for repair.

The 100 repetitions are confirmation of the protocol contract, not an attempt to statistically prove message ordering. The design removes the normal response-vs-interrupt race by not writing the response at all.

### Timeout fallback

If interruption is not observed within a bounded timeout:
- inspect authoritative Task/Attempt/Turn state;
- determine whether interrupt was accepted/processed or merely send-enqueued;
- only if the Turn remains active and the server request is still pending may GX send a fallback tool response;
- never send a fallback if the Turn is already terminal or the pending request was aborted;
- make fallback idempotent and record the residual extra-request risk.

Do not assume `client.send` completion means App Server processing. Instrument the observable protocol events.

Acceptance:
- 100 controlled local repetitions for accepted and terminal rejected outcomes;
- pending tool request closes without normal tool response;
- no post-terminal model request;
- no duplicate accepted/rejected settlement;
- no GX terminal interrupt counted as Root failure;
- usage/child-agent accounting reconciles without unexplained estimate;
- fallback tested under delayed/lost interrupt acknowledgement.

---

# 2. B1 — A+B+C and `science_grid@3` in one versioned change

## 2.1 A — terminal submission without Dynamic Tool Response

On successful acceptance or terminal scientific rejection:
1. Commit the authoritative GX transaction and receipt.
2. Persist a terminal reason such as `GX_ACCEPTED` or `GX_TERMINAL_REJECTED`.
3. Complete Goal if applicable.
4. Send Turn Interrupt.
5. Return a special `NO_TOOL_RESPONSE` result from the GX tool handler.
6. App Server client recognizes this sentinel and does not write a normal Dynamic Tool Response.
7. Codex 0.169 aborts the pending request through its native pending-server-request path.
8. Reconcile Turn terminal state and usage.

Do not use `NO_TOOL_RESPONSE` for SchemaInvalid or other recoverable validation failures. Those must return a normal structured error response.

Do not roll back accepted science if transport/interruption fails after commit. The durable GX receipt is authoritative. Recover terminal delivery on restart without repeating submission or scientific work.

Terminally rejected submissions should also interrupt, because subsequent read/re-submit calls will be rejected and waste model requests. Preserve the scientific rejection result and reason in GX.

Test at least one case where a native child agent is still running. Verify child usage is reconciled before final settlement or explicitly marked pending according to existing accounting rules. Do not claim precise final accounting while child usage is outstanding.

## 2.2 B — ProductContract with per-path expansion

The previous flat field list is insufficient for a review product that contains one finding per authorized path.

The contract must express:
- the exact authorized path set from frozen Attempt inputs;
- a model-authored map keyed by `path_id`;
- every authorized path required exactly once;
- no extra keys;
- model-only fields within each path finding;
- GX-derived fields added by GX per path;
- Evaluator-computed fields added by the evaluator per path.

Conceptual model payload:

```json
{
  "findings_by_path": {
    "path-A": {
      "reason": "model-authored interpretation",
      "risk": "model-authored risk"
    },
    "path-B": {
      "reason": "model-authored interpretation",
      "risk": "model-authored risk"
    }
  }
}
```

GX validates key equality against the frozen authorized path set. It then constructs final per-path findings by binding:
- GX fields: path ID, proposal/evidence/evaluation references from frozen inputs;
- Evaluator fields: validity, threshold result, `supported` when deterministically computable;
- Model fields: reason, interpretation, risk, limitations.

The model must not author GX-owned references or evaluator-owned outputs.

Do not use a single `attempt.bound_path_id` for a multi-path reviewer task.

### Semantic validators

`semantic` cannot be a list of prose labels. It must reference executable validator functions supplied by the versioned Workflow package, e.g.:
- `validate_frozen_evaluation_consistency`
- `validate_evidence_source_independence`
- `validate_path_coverage`
- `validate_measurement_validity`

Validator identity, package version and content digest are part of the Workflow pin. Validators receive immutable DTOs and return typed findings. They must not receive raw SQLite connections or perform network/model calls.

Structural schema validation and semantic validation remain distinct. A valid JSON structure does not prove a scientific claim.

## 2.3 Versioning — create `science_grid@3` now

B1 changes task instructions, contract, deterministic fields, evaluator behavior and potentially graph semantics. It must not mutate the pinned `science_grid@2`.

Implement `science_grid@3` once in B1, combining:
- ProductContract;
- GX-derived references;
- per-path findings;
- deterministic evaluator and `supported`;
- measurement-validity gate;
- conditional independent review;
- terminal submission behavior.

Do not create a partial `@3` in B1 and another `@3` in B4. B4 becomes deferred extraction/reuse work only if a second workflow needs a generic Product/Evaluator API.

Historical `science_grid@2` Runs must cold-resume unchanged.

### Reviewer semantics

The programmatic evaluator can replace deterministic checks, not independent scientific judgment.

Skip an independent Reviewer only when:
- measurement validity is established;
- all required numerical/threshold rules are deterministic;
- no contradictory evidence exists;
- no mechanism interpretation or uncertain scientific claim remains.

Keep an independent Reviewer for ambiguous claims, competing explanations, conflicting evidence, or decisions that require scientific interpretation.

If `supported` is computed by GX, remove it from the model-authored schema. Do not ask a reviewer to re-derive it.

---

# 3. C — Same-Attempt repair with durable bounded counter

Reuse current `SchemaInvalid` path:
- structural validation before Artifact publication;
- raise `SchemaInvalid`;
- current transaction rolls back;
- return structured `success:false` to the same Agent;
- preserve Task, Attempt, Lease and scientific Job;
- no invalid Artifact.

Do not add a submission state machine.

### Important receipt correction

Current failed Tool calls do not create the successful-call receipt because the submission transaction rolls back. Therefore a repair counter cannot be incremented only inside that transaction.

Implement a small separate post-rollback accounting transaction:
- key by `(attempt_id, tool_call_id)` or the strongest stable unique call identifier available;
- record validation failure category and contract digest;
- increment repair count only once per distinct failed call;
- replay of the same failed call returns the same validation error and does not increment again;
- a corrected payload/new tool call ID counts as a new repair attempt;
- counter survives process restart;
- no Artifact or Task state mutation occurs in the failed submission transaction.

Initial maximum: 2 distinct structural failures per Attempt, configurable. On limit, return a bounded terminal/review outcome according to existing failure semantics.

Do not count transport retries or identical call replay. Recheck authorization and evidence provenance on every new submission.

Scientific rejection is not schema repair. Measurement failure is not negative evidence.

---

# 4. B2 — E role-based tool policy

Decide tools from role responsibilities first; use logs to validate, not to veto sensible restrictions.

Example policy:
- Reviewer of frozen evidence: read context/artifacts + submit review; no new Job creation unless its assigned task explicitly requires independent computation.
- Planner: read evidence/context + submit decision/product; no arbitrary compute by default.
- Researcher: read, propose/submit Jobs, wait, publish required outputs.
- Compute Worker: only tools needed to prepare/submit/inspect its assigned computation.

Use actual existing tool names. Do not invent tools.

Multi-Agent:
- off by default for roles that do not need delegation;
- enabled for roles/tasks with actual parallel decomposition value;
- preserve native Codex subagents and test inheritance.

Instruction optimization:
- keep Codex BaseInstructions unchanged;
- only test GX Developer Instructions;
- compare first-request token and output quality separately.

B2 is a separate commit and report. It may proceed alongside B1 if no shared hot-path changes are mixed.

---

# 5. B3 — D small Artifact preload; no new Context Snapshot subsystem

Do not add a generic Context Snapshot or new freshness/invalidating framework.

Existing Artifacts are immutable and have refs/digests. Existing Task Brief has `brief_sha256`. Intent and supplemental-source changes already use notification paths.

Do only:
1. At Task Brief creation, embed the small authorized Artifact contents needed by the role.
2. Remove duplicate `gx_task_context` calls when the exact same context is already in the brief.
3. Keep large PDB/mmCIF, sequence collections, papers, arrays and raw compute outputs lazy-loaded.
4. Keep source Artifact refs/digests in the brief so provenance is explicit.
5. Respect existing brief hash/versioning; new brief content changes the brief digest.

Initial cap for this benchmark:
- each preloaded JSON Artifact <= 16 KB;
- total preloaded payload <= 16 KB.

This is a measured workload limit, not a new global context framework. If an input exceeds cap, leave it lazy and record why.

Measure total Tokens, requests, wall time, compaction, and stale-reference incidents. Stale incidents must be zero.

---

# 6. F — deterministic evaluation (implemented as part of `science_grid@3`)

Do not defer the actual science_grid evaluator to a later second `@3`.

Preserve existing measurement-validity checks from `science_grid@2`:
- only valid measurements can generate positive or negative support;
- failed measurements are not negative evidence;
- evaluator must verify the measurement result is complete and corresponds to the frozen input.

Inline evaluator:
- standard library only;
- pure/deterministic;
- bounded input size and execution time;
- no network, subprocess, raw DB or arbitrary filesystem.

Heavy evaluator:
- existing Capability Manifest + Job Runtime.

Evaluation order:
1. structural ProductContract validation;
2. measurement validity;
3. deterministic derived-field calculation;
4. executable semantic validation;
5. determine whether scientific review remains necessary;
6. independent review when genuine uncertainty remains;
7. persist Evaluation/Evidence/Decision with provenance.

---

# 7. H/B0 — request telemetry and mechanical classification

Do not use subjective Research/Execution labels as the primary request classifier.

Use response ID, tool calls and workflow phase to mechanically classify:
- `READ`: context/artifact/evidence retrieval only;
- `PRODUCE`: first product submission attempt;
- `REPAIR`: response after structural/schema failure;
- `POST_SUBMIT`: response after accepted or terminally rejected submission;
- `OTHER_CONTROL`: other control/coordination-only activity;
- `MIXED`: multiple categories in one response;
- `UNCLASSIFIED`: insufficient event evidence.

Record per model response:
- response ID;
- Run/Task/Attempt/Root/Turn IDs;
- ordinal and timestamp;
- input/output/cache/reasoning/total tokens when actually supplied;
- model/provider;
- linked tool calls and classification.

Existing per-Turn totals cannot be used to invent per-request input tokens. Add per-response telemetry first. Preserve existing cumulative usage accounting as the authoritative budget ledger; attribution records must not double-charge.

A small instrumented wave after telemetry is sufficient to measure first-request and per-class tokens. Do not rerun the full expensive baseline.

Scientific contribution should be measured separately by accepted MODEL-authored fields, independently accepted evidence-based decisions, and quality evaluation—not by subjective request labels.

---

# 8. Benchmark and acceptance

Use the existing 13-wave protocol after B1, with a bounded one-arm run. Compare:
1. first-review rejection rate;
2. model requests after accepted/terminally rejected submission;
3. estimated usage settlements;
and additionally:
- total Tokens;
- per-Run wall time;
- repair count;
- duplicate Artifact count;
- accepted Product count;
- accepted evidence-based decisions;
- request-class distribution.

Do not compare only Tool Call count.

Scientific quality benchmark is separate and must include competing hypotheses, alternative methods, mid-run additional sources, next-candidate selection, contradictory/negative evidence and independent review.

---

# 9. Four concise reports only

Consolidate deliverables into four reports:
1. `V31_SOURCE_AND_BASELINE.md` — source audit, baseline, telemetry limits, protocol findings.
2. `V31_B1_SUBMISSION_PROTOCOL.md` — A+B+C, `science_grid@3`, protocol race, 13-wave one-arm results.
3. `V31_B2_B3_EFFICIENCY.md` — role tools, Multi-Agent, instructions, Artifact preload.
4. `V31_LIMITATIONS_AND_NEXT_STEPS.md` — residual risks, F/B4 extraction decision, scientific benchmark status.

Do not create separate deployment/rollback reports for a development branch unless a real deployment/migration was performed. Preserve raw machine-readable test receipts under `acceptance/`; reports link to them.

---

# 10. Implementation sequence

1. B0 source audit and protocol probe using local scripted model.
2. Add per-response usage telemetry and mechanical classification; run one small capped instrumented wave.
3. B1: A no-response terminal path + C durable post-rollback repair counter + B ProductContract + `science_grid@3` deterministic evaluation in one versioned workflow release.
4. B2 E in a separate commit; may run in parallel with B1 only if no shared code is mixed.
5. B1 bounded 13-wave one-arm after local protocol and integration tests.
6. B3 D small Artifact preload and duplicate context removal.
7. B4 generic API extraction deferred until a second Workflow needs it; do not create speculative API now.
8. B5 scientific quality benchmark.

Every batch gets focused tests and full relevant regression. Preserve current v3 branch and v2.1 fallback. Inspect actual HEAD and user changes; never reset or force-push.

---

# 11. Definition of done

B1 is complete only if:
- accepted and terminally rejected submissions do not receive a normal Dynamic Tool Response on the proven Codex abort path;
- no post-terminal model request occurs;
- GX terminal completion is not Root failure;
- usage, including child-agent usage, reconciles;
- ProductContract enforces exact per-path coverage;
- GX and Evaluator fields are derived, not model-authored;
- semantic validators are executable and pinned with `science_grid@3`;
- schema failures repair same Attempt, with durable distinct-call counter and no invalid Artifact;
- `science_grid@2` remains unchanged and cold-resumable.

B2 is complete only if role-based tools/Multi-Agent reduce overhead without removing required capabilities.

B3 is complete only if embedding small immutable Artifacts and removing duplicate context retrieval reduces total Tokens/time with zero stale-reference incidents.

Do not declare scientific quality improved based on efficiency metrics. Report it separately.
