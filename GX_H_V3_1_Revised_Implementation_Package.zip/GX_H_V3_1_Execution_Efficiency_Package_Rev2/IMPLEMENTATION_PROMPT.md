# Agent Prompt — Implement GX-H v3.1 (Revised Source-Aligned Plan)

You are the principal GX engineer and independent acceptance owner. Implement the attached revised `GX_H_V3_1_BLUEPRINT.md` against the actual current `v3` branch of `AshHuHK/gx-h-v2`.

Read the blueprint fully before coding. The goal is fewer unnecessary model requests, exact usage accounting, correct product delivery, and preserved scientific validity.

## 1. Repository safety and audit

Run:
```bash
git status --short
git branch --show-current
git rev-parse HEAD
git log --oneline -25
```
Inspect actual HEAD. Preserve all later commits and local changes. Do not reset, force-push or overwrite user work.

Trace exact source paths and call graph for:
- `hostobs/app_server_client.py` dynamic tool handler and response write;
- App Server `client.send` and `_request`;
- `turn/interrupt`, `thread/goal/set`;
- Codex 0.169 pending-server-request abort behavior;
- `p0/roots.py` product submission, receipts and terminal handling;
- `teams/service.py` validation, Artifact publication and `SchemaInvalid`;
- `errors.py`;
- `p0/metering.py` and per-response completion events;
- Task Brief and `gx_task_context`;
- role profiles, actual tool names and call logs;
- `science_grid_v2/nodes.py` review product and measurement validity;
- plugin Author API and current Workflow binding;
- existing 13-wave receipts.

Create only the four consolidated reports specified in the blueprint. Raw machine-readable receipts belong under `acceptance/`.

## 2. Non-negotiable constraints

- Do not modify or upgrade Codex.
- Do not replace Codex Agent Runtime or native Subagents.
- Do not add a Work Unit entity or five-state submission machine.
- Reuse existing Task/Attempt/Lease/Goal, `SchemaInvalid`, tool receipt and metering owners.
- Accepted/terminally rejected state must be durably committed before interrupt.
- Do not write a normal Dynamic Tool Response after terminal submission on the proven pending-request-abort path.
- Do not interrupt recoverable SchemaInvalid responses.
- Do not call a structurally valid Product scientifically accepted without semantic/evidence checks.
- Do not change `science_grid@2`; create `science_grid@3` once for B1 semantics.
- Do not add a generic Context Snapshot subsystem.
- Do not add generic Event Bus or plugin lifecycle framework.
- Do not change Codex BaseInstructions.
- Do not use subjective Research/Execution classification as primary telemetry.
- Do not claim per-request tokens from turn-level aggregates.
- Do not weaken measurement validity, evidence provenance, independent review where needed, Lease/Fencing, budget or Artifact integrity.

## 3. B0 — prove the no-response terminal protocol

The source hypothesis is that Codex 0.169 aborts pending dynamic server requests when a Turn is interrupted:
- App Server aborts pending server requests;
- dynamic tool layer receives a transition error and does not write normal tool response;
- core cancels the pending dynamic tool call.

Verify against the exact checked-out Codex source/binary and App Server protocol. Do not assume this source path matches the deployed binary without version/SHA evidence.

Build a local scripted-model protocol probe:
1. Start a Turn and hold a GX dynamic tool call pending.
2. Commit accepted or terminally rejected GX state.
3. Send Goal Complete if applicable.
4. Send Turn Interrupt.
5. Return a special `NO_TOOL_RESPONSE` sentinel from the GX handler.
6. Client must not write a normal Dynamic Tool Response.
7. Verify App Server aborts the pending request and no subsequent model request starts.
8. Verify usage and child-agent accounting.
9. Verify GX-originated interrupt is not Root failure.

Test both accepted and terminal rejected outcomes. SchemaInvalid remains a normal error response for same-Attempt repair.

Add a bounded fallback only if interrupt is not processed:
- query authoritative Turn/Task state;
- send fallback response only while Turn is still active and request remains pending;
- never send after abort/terminal state;
- make fallback idempotent and auditable.

Run at least 100 controlled local repetitions with varied delays, plus child-agent-running scenario. These are protocol tests, not paid model tests.

Do not implement based solely on `client.send` enqueue completion. Instrument actual App Server event/transition.

Deliver protocol findings in `V31_SOURCE_AND_BASELINE.md`, with raw receipts.

## 4. B0 — usage telemetry

Current baseline has turn-level total usage, not per-response input tokens. Do not infer missing values.

Record every response completion event:
- response ID;
- Run/Task/Attempt/Root/Turn IDs;
- request ordinal/time;
- input/output/cache/reasoning/total Tokens when supplied;
- model/provider;
- linked Tool calls.

Preserve existing cumulative Thread/Turn budget ledger. Per-response records are attribution only; never double-charge.

Mechanically classify responses:
- READ;
- PRODUCE;
- REPAIR;
- POST_SUBMIT;
- OTHER_CONTROL;
- MIXED;
- UNCLASSIFIED.

Use tool events and workflow phase, not natural-language judgement. Existing receipts can supply counts where available, but not missing per-request tokens. Add telemetry, then run one small capped instrumented wave.

## 5. B1 — A+B+C and `science_grid@3`

### A. Terminal accepted/rejected submission

In existing authoritative transaction:
- commit receipt and accepted/terminal-rejected state;
- persist terminal reason (`GX_ACCEPTED` / `GX_TERMINAL_REJECTED`);
- then Goal Complete and Turn Interrupt;
- return `NO_TOOL_RESPONSE`;
- App Server client suppresses normal Dynamic Tool Response.

Use this for accepted submission and terminal scientific rejection. Do not use it for recoverable SchemaInvalid.

If interruption/transport fails after commit, accepted/rejected state remains authoritative. Reconcile terminal delivery after restart; never rerun scientific work or duplicate settlement.

### B. ProductContract

Implement a per-path contract for reviewer tasks:
- frozen authorized path set;
- `findings_by_path` object keyed by path ID;
- exact key equality: every authorized path once, no extra path;
- each model entry contains only MODEL-authored fields;
- GX binds path/proposal/evidence/evaluation references;
- Evaluator adds deterministic fields such as measurement validity and `supported`.

Generate Task Brief, Tool schema and structural server validation from one versioned contract.

Semantic validators must be executable functions in the versioned workflow package, not prose strings. Pin their identity/version/digest with `science_grid@3`.

Separate structural, semantic, provenance and scientific judgment. A valid ref is not proof that the ref supports the claim.

### Versioning

Create `science_grid@3` once in B1. Do not mutate `science_grid@2`, and do not create a second `@3` in a later evaluator batch.

B1 `@3` includes:
- per-path ProductContract;
- GX-derived fields;
- deterministic supported evaluator;
- measurement validity gate;
- conditional independent review;
- terminal submission semantics.

Skip Reviewer only when all checks are deterministic and no uncertainty/conflicting evidence/mechanism interpretation remains. Keep an independent Reviewer for genuine scientific judgment.

### C. Same-Attempt repair

Reuse `SchemaInvalid`:
- structural checks before Artifact publication;
- rollback submission transaction;
- return normal structured error to same Agent;
- preserve Task/Attempt/Lease/Job;
- no invalid Artifact.

Because failed calls currently roll back and do not leave successful-call receipts, persist repair accounting in a separate small post-rollback transaction keyed by Attempt + stable Tool Call ID:
- distinct failed call increments once;
- same call replay returns same error and does not increment;
- corrected new call increments if it fails again;
- counter survives restart;
- transport retries do not increment.

Initial maximum 2 distinct structural failures per Attempt, configurable. No new submission state machine.

## 6. B2 — role tool policy

Use role semantics first, logs second:
- Reviewer of frozen evidence: no Job creation by default.
- Planner: read/decide/submit, no arbitrary compute by default.
- Researcher: Job tools where required.
- Compute Worker: assigned compute tools only.

Use actual tool names. No invented tools. Multi-Agent off by default where delegation is not required; preserve native Codex Subagents where needed. GX instruction A/B only; Codex BaseInstructions unchanged.

Separate commit/report. Verify child-agent inheritance.

## 7. B3 — small preload, no Context Snapshot subsystem

At Task Brief creation embed small authorized immutable Artifact content:
- each JSON Artifact <=16 KB;
- total <=16 KB for this workload.
- include existing Artifact refs/digests.
- large scientific structures, sequence collections, papers and arrays stay lazy.
- remove duplicate `gx_task_context` when same data is already in brief.
- use existing brief hash and change-notification paths; no new freshness engine.

Measure total Tokens/time, request count, compaction and stale references. Zero stale reference incidents.

## 8. F and B4 — evaluator placement

Implement deterministic evaluator as part of `science_grid@3`, not a later second `@3`.

Preserve measurement validity. `supported` is evaluator-derived, not model-authored.

Inline evaluator: pure stdlib-only, bounded time/size, no network/subprocess/raw DB/filesystem.

Heavy evaluator: existing Capability Manifest + Job Runtime.

Keep independent reviewer when scientific judgment remains. Historical `science_grid@2` runs must cold-resume unchanged.

Generic `ctx.products.register(...)` extraction is deferred until a second Workflow genuinely needs it. Do not speculate a broad API now.

## 9. B0–B5 metrics and reports

Use mechanical request classes and per-response telemetry. Report:
- request count and per-response tokens by class;
- first-request input Tokens;
- first-submission rejection;
- post-terminal requests;
- estimated settlement count;
- repair count;
- duplicate Artifacts;
- accepted Products;
- evidence-based Decisions;
- per-Run wall time.

Efficiency and scientific quality are separate. Do not call all non-accepted requests waste. Do not classify scientific reasoning as Control merely because no Product was submitted.

## 10. Reports: only four

Create:
1. `V31_SOURCE_AND_BASELINE.md`
2. `V31_B1_SUBMISSION_PROTOCOL.md`
3. `V31_B2_B3_EFFICIENCY.md`
4. `V31_LIMITATIONS_AND_NEXT_STEPS.md`

Preserve raw test receipts under `acceptance/`. No deployment/rollback report for a development branch unless actual deployment/migration occurs.

## 11. Sequence

1. B0 source audit + local protocol probe.
2. Add per-response usage telemetry + mechanical classification; one small capped wave.
3. B1 A+B+C + `science_grid@3`.
4. B2 E separate commit; may proceed in parallel only without mixing shared changes.
5. B1 bounded 13-wave one-arm.
6. B3 D.
7. B4 generic evaluator API extraction only when a second workflow needs it.
8. B5 separate scientific-quality benchmark.

Each batch gets focused tests and full relevant regression. Keep v2.1 and current v3 fallback.

## 12. Definition of done

B1 passes only when:
- terminal accepted/rejected submissions do not receive normal Tool Response on proven Codex abort path;
- no post-terminal model request;
- GX interrupt is not Root failure;
- usage including child-agent usage reconciles;
- per-path coverage is exact;
- GX/Evaluator fields are not model-authored;
- executable semantic validators are pinned to `science_grid@3`;
- schema repair stays in same Attempt, bounded and durable;
- no invalid Artifact or duplicate settlement;
- `science_grid@2` remains unchanged and cold-resumable.

B2/B3 pass only with measured total Token/time improvement and no quality/provenance regression.

Scientific quality is reported independently. Do not declare all v3.1 complete until all applicable batches and evidence gates pass.
