# GX-H v3.1 Revised Implementation Package

This revision supersedes the earlier v3.1 efficiency package.

Key corrected decisions:
- A uses Codex pending-server-request abort: after accepted/terminally rejected commit, suppress normal Dynamic Tool Response and interrupt the Turn. Protocol probe confirms the exact pinned runtime; fallback is bounded and state-aware.
- B uses per-authorized-path `findings_by_path`, then GX/Evaluator enriches each path.
- B1 creates `science_grid@3` once; B4 does not create another `@3`.
- Semantic validation references executable version-pinned functions.
- C persists distinct failed Tool Call repair counts in a separate post-rollback transaction.
- D embeds small immutable Artifacts in existing Task Brief; no new Context Snapshot subsystem.
- E uses role semantics first, call logs as verification.
- H is mechanically classified from response/tool events; per-response token telemetry must be added because Turn totals cannot reconstruct it.
- Reports are consolidated to four.

Contents:
- `GX_H_V3_1_BLUEPRINT.md`
- `IMPLEMENTATION_PROMPT.md`
- `contracts/per-path-product.schema.json`
- `examples/per-path-review.model-payload.json`
- `acceptance/V31_ACCEPTANCE_MATRIX.md`
- `specs/REPORTING.md`

This is an implementation handoff, not evidence that the changes are implemented.
