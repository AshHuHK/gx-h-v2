# GX-H v3.1 Revised Acceptance Matrix

## B0
- [ ] Actual source branch/HEAD and Codex binary/source version recorded.
- [ ] Existing 13-wave receipts reconciled; no unnecessary full paid baseline.
- [ ] Per-response usage telemetry stores only provider-supplied values.
- [ ] Mechanical request classification uses tool events/workflow phase.
- [ ] Small capped instrumented wave records first-request input tokens.
- [ ] Local protocol probe covers accepted and terminal-rejected no-response paths.
- [ ] 100 controlled repetitions include delayed interrupt and child-agent-running case.

## B1 A — terminal no-response
- [ ] Accepted receipt commits before Goal/Interrupt.
- [ ] Terminal rejection also uses terminal interrupt path.
- [ ] Recoverable SchemaInvalid returns normal Tool error and is not interrupted.
- [ ] `NO_TOOL_RESPONSE` prevents normal Dynamic Tool Response write.
- [ ] Pinned Codex aborts pending server request.
- [ ] No post-terminal model request.
- [ ] GX terminal interrupt not Root failure.
- [ ] Usage reconciles including child-agent usage.
- [ ] Timeout fallback only when Turn remains active and request pending.

## B1 B — ProductContract / science_grid@3
- [ ] Per-path map keys exactly equal frozen authorized path set.
- [ ] Missing and extra path keys rejected structurally.
- [ ] Model supplies only MODEL fields.
- [ ] GX binds refs and GX-owned fields.
- [ ] Evaluator computes deterministic fields.
- [ ] Semantic validators are executable, versioned and digest-pinned.
- [ ] Measurement validity checked before support/refutation.
- [ ] Reviewer skipped only when no genuine scientific judgment remains.
- [ ] `science_grid@2` unchanged and cold-resumable.

## B1 C — same-Attempt repair
- [ ] Structural error before Artifact publication.
- [ ] Failed transaction rolls back.
- [ ] Separate post-rollback counter records distinct Tool Call ID once.
- [ ] Replayed failed call does not increment.
- [ ] New corrected call can repair same Attempt.
- [ ] Counter survives restart.
- [ ] Maximum repair count enforced.
- [ ] No new Attempt, Lease or scientific Job for schema repair.
- [ ] No invalid Artifact or duplicate Accepted Receipt.

## B1 combined 13-wave one-arm
- [ ] First-review rejection rate.
- [ ] Post-accepted/terminal-rejected request count.
- [ ] Estimated usage settlements.
- [ ] Total tokens, wall time, repair count, duplicate Artifact count.
- [ ] Results and limitations clearly reported.

## B2 E
- [ ] Role tool policy justified by role semantics and checked against logs.
- [ ] Reviewer frozen-evidence profile does not expose unnecessary Job creation.
- [ ] Researcher/Compute Worker retain required Job tools.
- [ ] Native subagent behavior tested where enabled.
- [ ] No invented tools.
- [ ] GX instruction A/B; Codex BaseInstructions unchanged.

## B3 D
- [ ] Small authorized immutable Artifacts injected into existing Task Brief.
- [ ] <=16 KB per item and <=16 KB total for this workload.
- [ ] Large scientific inputs remain lazy.
- [ ] Duplicate gx_task_context removed where exact content already in brief.
- [ ] Existing Artifact digests and brief_sha256 preserved.
- [ ] Zero stale-reference incidents.
- [ ] Total Tokens and wall time measured.

## B4/B5
- [ ] Generic Product/Evaluator API extraction deferred until second workflow requires it.
- [ ] Scientific quality benchmark separate from efficiency.
