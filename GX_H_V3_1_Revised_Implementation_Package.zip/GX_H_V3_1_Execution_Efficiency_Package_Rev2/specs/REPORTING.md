# Required report set (four reports only)

1. `V31_SOURCE_AND_BASELINE.md`
   - source audit, call graph, transaction boundaries, Codex protocol findings, existing 13-wave evidence, per-response telemetry gap, mechanical classification.

2. `V31_B1_SUBMISSION_PROTOCOL.md`
   - A no-response terminal behavior, accepted/rejected outcomes, B per-path ProductContract, executable validators, `science_grid@3`, C post-rollback repair counter, 100 protocol repetitions, bounded 13-wave one-arm.

3. `V31_B2_B3_EFFICIENCY.md`
   - role-specific tools, Multi-Agent policy, GX instruction A/B, small Artifact preload, duplicate context removal, per-class usage and wall-time comparison.

4. `V31_LIMITATIONS_AND_NEXT_STEPS.md`
   - residual race/fallback risk, child-agent usage, scientific reviewer boundaries, B4 API extraction trigger, B5 scientific quality benchmark status.

Keep raw machine-readable receipts and logs under `acceptance/`. Do not create separate deployment/rollback reports for a development branch unless an actual deployment/migration occurs.
