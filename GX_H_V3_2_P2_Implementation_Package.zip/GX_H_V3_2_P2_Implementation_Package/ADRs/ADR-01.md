# ADR-01 — GX Persistent Ownership & Agent Driver
Status: Proposed. GX 是唯一持久运行主体和权威状态唯一写者。Codex 是按需 Driver。
分开两种契约：**Decision Session** 接收冻结 Goal/Graph head/evidence/budget，持有 Decision Lease + base_version，可提出 submit/amend/resolve，但 GX 才能 validate/commit；**Agent Task Session** 执行有界非确定性节点，只提交当前 Task 结果，不得改 Graph/Goal/budget。Native Subagents 由 Codex 管理，GX 服务端按 Run/Task/Lease/thread/turn 授权。
Human/PI 拥有 Goal Contract 和硬预算上限，可批准放宽/增预算/改范围/接管；接管先撤销 Decision Lease。Codex 不可用时受影响 scope 持久 WAITING_DECISION 并通知，独立 branch 可继续。Driver 记录 driver/provider/model/effort/session/usage/terminal provenance。
验收：Codex 退出 GX 仍推进确定性节点；Task Session 改 Graph 被拒；撤销 Lease 后迟到 proposal 被拒；Codex outage 不导致整个 Run 终止。
