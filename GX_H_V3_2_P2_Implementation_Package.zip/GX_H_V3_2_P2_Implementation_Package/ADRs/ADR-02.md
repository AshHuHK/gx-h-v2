# ADR-02 — Plugin Recipe, GX Runtime & Durable Compute
Status: Proposed. Plugin 可带 Graph Recipe、Node Handler、Tool/Schema、Capability Manifest、Evaluator。Graph 是 recipe，不是运行中的计划；GX 展开默认参数、绑定 Goal/资源/seed/digests，校验并创建 immutable GraphVersion。
GX 拥有 Graph/Node 状态、Attempt、retry、budget、Artifact/Evidence、branch 和 recovery。Node 不可隐藏无界循环、私有 scheduler 或 unmanaged Job。方法阈值可显式版本化，Goal 阈值只能来自 Human Goal Contract。
Job 必须 Attempt-first：先持久化 Attempt/submission intent，再提交后端；job name 派生 attempt_id；重启按稳定 backend identity 对账，不能盲目重提。Checkpoint 能力在 Manifest 声明；续算创建新 Attempt，引用 parent Attempt 和 checkpoint Artifact。
验收：独立 Plugin Graph 能运行；隐藏 Goal 阈值被拒；崩溃后不重复提交 Job；checkpoint 有新 Attempt lineage。
