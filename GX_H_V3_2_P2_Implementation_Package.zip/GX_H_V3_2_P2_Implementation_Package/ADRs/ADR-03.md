# ADR-03 — Goal Authority & Scientific Acceptance
Status: Proposed. Goal Contract 分两层：机械标准（metric/unit/operator/threshold/allowed Evaluator family/provenance/budget/deadline）与科学目标（生物物理解释、proxy 限制、正交证据/湿实验、人类签署）。
只有 Human/PI 可放宽 Goal、增加硬预算、改范围或批准 Goal metric 的 Evaluator producer 变更。Evaluator 只输出 typed Measurement，不输出权威 accepted=true；GX 按 Goal Contract 计算 computational acceptance。超出机械标准的科学结论等待 Human sign-off。
指标需标注 direct measurement / numerical verification / model-derived proxy / heuristic / experimental result。高 pLDDT/ipTM/界面面积不自动证明结合或活性。
验收：Codex 放宽 Goal/增预算被拒；未批准 Evaluator 替换被拒；未类型化 pass 被拒；proxy metric 只能得到 computational status。
