# ADR-04 — Immutable GraphVersion & Execution Reuse
Status: Proposed. GraphVersion 不可变，包含展开后的参数、节点边、monitor/branch/retry、精确 Plugin/Node/Capability/Evaluator digest、Goal、资源、seed、作者和 DecisionRecord。
Node Attempt 记录 attempt_id、Run、logical node、GraphVersion、plan_key、exec_key、实现/Capability digest、输入 Artifact digest、语义参数、seed、环境/model provenance。exec_key 包含改变科学含义/输出分布的参数和随机 seed；placement-only hints 不进入 key。新 seed 必须创建新 Attempt/sample batch。
amend 带 run_id/base_version/decision_lease_id/draft digest/idempotency key；GX CAS commit。并发修改一方成功，另一方冲突后 rebase。只冻结受影响 branch；无关完成产物复用，运行中节点仅在 key/lease 仍有效时 adopt。
验收：GraphVersion 不可变；同 base 并发只有一个成功；改 seed 新 Attempt；改一个下游节点不重跑无关节点。
