# ADR-05 — Native Submission & Terminal Protocol
Status: Proposed; based on v3.1 evidence and pinned Codex 0.169.0. 保留终态提交协议，封装在版本化 CodexProtocolAdapter，不让业务层直接依赖特殊协议值。
接受/终局拒绝时原子保存裁决、Artifact refs、callback receipt、terminal reason；按官方 Turn history、终态和 provider usage 对账，ACK 单独不足。丢失/迟到 ACK 幂等处理。缺失用量不得伪造，按既有策略标记 unknown/estimated。
结构错误先回滚产品事务，再独立持久化错误，按 Root/Turn/Call/request digest 幂等；允许有限同 Attempt 修复。结构修复计数与 Job retry、科学结论分开。Codex 升级需通过协议兼容测试；不支持的版本安全降级或 fail closed。
验收：重复 Call 不重复 Artifact；commit 后崩溃可恢复；ACK 丢失不产生重复中断/新模型回合；同 Attempt 修复成功。
