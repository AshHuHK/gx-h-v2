# ADR-06 — Agent Roles, Tool Catalog & Context Delivery
Status: Proposed; preserve v3.1 B2/B3. Reviewer/Planner/Researcher/Executor 按职责获得最小工具目录。目录过滤是最小权限体验，不是安全边界；GX 服务端按 Run/Task/Lease/thread/turn/Artifact citation scope 验证每次调用。Native Child、普通 Fork、其他 Run 和过期 Lease 区分处理。
Task Brief 可预载小型、已授权、不可变 Artifact 摘要，携带 ref + SHA-256，限制单项/总大小（v3.1 为 16 KiB）；大数组延迟读取。Brief 是快照，不是实时状态；需要新鲜度时重新读取。GX 从结构化记录编译权威历史摘要，Agent 笔记非权威。
验收：角色工具目录正确；Child 只能访问授权 Artifact；digest/大小限制正确；过期 Brief 不覆盖当前权威状态。
