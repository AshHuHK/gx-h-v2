# GX-H v3.2 / P2 Package
基线：v3.1 HEAD `91ea828a8892d6e2ce125fe89cd5d5a13df18598`。本包是实施蓝图，不代表目标已实现；Agent 必须先审计源码。

架构：Human/PI 拥有 Goal Contract 与硬预算上限；GX 是唯一持久运行主体和权威状态唯一写者；Codex 是按需 Agent Driver，分 Decision Session 与 Agent Task Session；Plugin 携带 Graph Recipe、Node、Tool、Capability、Evaluator；GX 执行 Graph；Compute Runtime 承载可超越进程生命周期的 CPU/GPU/HPC Job。

原则：保护 v3.1 已有 terminal protocol、同 Attempt 修复、science_grid@3 确定性评估、角色工具范围、Brief Preloading、Native Child 恢复。不要新建 Agent Manager、Scheduler、Job Manager、Budget、Artifact Store、Event Bus 或 Workflow Engine。`science_grid@3` 保留兼容，不强搬出核心。P2 必须由第二个独立 Plugin 证明通用性。
