# P2 Acceptance Matrix
| ID | 用例 | 证据 |
|---|---|---|
| A01 | Codex 全部退出，GX 仍推进确定性节点/等待 Job | 事件轨迹+DB snapshot |
| A02 | Agent Task 尝试改 Graph/Goal/budget | 服务端拒绝 |
| A03 | 撤销 Decision Lease 后迟到提交 | 拒绝，Graph head 不变 |
| A04 | Codex/Plugin 放宽 Goal 或提高硬预算 | 拒绝 |
| A05 | Recipe 默认值展开、digest pin | GraphVersion payload/hash |
| A06 | Plugin 自带新 Capability | 安装批准和 Manifest digest |
| A07 | 隐藏 Node 循环/unmanaged Job | 合同测试拒绝 |
| A08 | Evaluator typed Measurement、GX adjudication | Measurement+GX verdict |
| A09 | 未批准 Goal Evaluator 替换 | 拒绝 |
| A10 | Attempt 先于外部 Job submit | 有序 DB/event trace |
| A11 | Scheduler 接受后 GX 崩溃 | 重启对账，无重复 Job |
| A12 | Checkpoint 续算 | 新 Attempt + parent/checkpoint refs |
| A13 | 两个 amendment 同 base | 一个 CAS 成功，一个冲突 |
| A14 | 一条 branch 等待，另一条继续 | branch trace |
| A15 | 改下游节点 | 无关输出复用 |
| A16 | 新 seed | 新 exec_key/Attempt |
| A17 | v3.1 terminal/repair/cold recovery 回归 | 原专项测试 |
| A18 | Native Child scope/recovery/usage | 官方宿主轨迹 |
| A19 | Brief digest/size/freshness/lazy read | Artifact digest+测试 |
| A20 | Plugin Graph 不依赖 science_grid | import audit+运行证据 |
| A21 | 未批准 container digest | backend 拒绝 |
| A22 | proxy metric 不等于科学签署 | computational status+human pending |
证据标签必须区分 SCRIPTED、OFFICIAL_HOST_LOOPBACK、LIVE_MODEL、REAL_COMPUTE、INDEPENDENT_REVIEW。
