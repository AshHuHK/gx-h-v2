# ADR Adversarial Cases
1. Plugin 把较弱 Goal threshold 伪装成 method parameter：拒绝。
2. Codex 增加硬预算上限：拒绝。
3. Agent Task 改 Graph：拒绝。
4. 人类撤销 Decision Lease 后 Codex 迟到提交：拒绝。
5. 两个 amendment 同 base：一方成功，另一方 rebase。
6. Evaluator 只返回 accepted=true：拒绝。
7. 未批准的宽松 Goal Evaluator 替换：拒绝。
8. Node 直接提交未登记 Slurm Job：拒绝/检测。
9. GX 在 Scheduler 接受后崩溃：按 attempt identity 对账。
10. Checkpoint 损坏/不兼容：拒绝续算，保留旧 Attempt。
11. 新 seed 却提供旧 exec_key：重新计算并拒绝。
12. Node 隐藏无界 generate/filter/retry：合同违规。
13. 一条 branch 等 Codex，独立 branch 完成。
14. Codex 数小时不可用：WAITING_DECISION+通知，不终止整个 Run。
15. Proxy metric 通过但无正交证据：仅计算验收，人类签署待定。
16. Brief 过期：要求重新读取当前 Artifact。
17. Native Child 读取无关 Artifact/过期 Lease：拒绝。
18. 不支持的 Codex 版本：terminal optimization fail closed 或安全降级。
