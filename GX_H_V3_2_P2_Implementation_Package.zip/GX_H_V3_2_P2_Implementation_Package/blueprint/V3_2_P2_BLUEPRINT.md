# GX-H v3.2 / P2 蓝图

## v3.1 现状
v3.1 已实现终态提交协议、同 Attempt 结构修复、science_grid@3 的确定性测量/独立解释分流、角色工具收敛、Brief Preloading、Native Child 权限和恢复。但 `org.gx.science-grid@3.0.0/plugin.py` 主要注册 workflow/version、Tool 和 Capability；Graph/Node 仍位于 `gx-h/workflows/science_grid_v3/` 并依赖既有 p0/旧 workflow。因此尚未证明第三方 Plugin 可独立携带完整 Graph。

## 责任边界
**Human/PI**：拥有 Goal Contract、硬预算上限；批准放宽目标、增预算、改科学范围、替换 Goal Evaluator；可暂停/接管，接管先撤销 Decision Lease；对超出机械验收的科学结论签署。

**GX**：唯一持久运行主体和权威状态唯一写者。管理 Run/GraphVersion/Task/Attempt/Lease/Job/Budget/Artifact/Evidence/Decision/Plugin Composition、Workflow Runtime、事件循环、恢复、外部 Job 对账。Codex 全部退出时，GX 仍可推进确定性节点、等待 Job、记录结果、等待人或决策。

**Codex**：按需启动。Decision Session 可提出 submit/amend/resolve，但只能由 GX validate/commit；Agent Task Session 只产出当前 Task 结果，不能改 Graph/Goal/预算。Native Subagents 仍由 Codex 管理，GX 服务端按 Run/Task/Lease/thread/turn 授权，不能依赖 Prompt。

**Plugin**：可带 Graph Recipe、Node Handler、Tool/Schema、现有格式 Capability Manifest、Evaluator 和领域元数据；不能自带持久调度器或 Workflow Runtime。

**Compute Runtime**：执行 CPU/GPU/容器/HPC/Slurm Job；GX 负责登记、准入、对账、结算。

## Recipe -> GraphVersion
Plugin Graph 是配方，不是可直接运行的计划。GX 解析精确 digest、展开默认参数、绑定 Goal/资源/seed/branch/monitor/stop rules，校验后创建不可变 GraphVersion，记录作者、recipe digest、参数、DecisionRecord 和验证摘要。方法阈值可显式版本化；Goal 阈值只能来自 Human-owned Goal Contract。

## Node 粒度
Node 是可观察、可计量、可恢复、可复用的工作单元。禁止隐藏 `generate -> filter -> retry -> regenerate -> evaluate` 无界循环、私有调度器或未登记 Job。具有独立预算、重试、中间 Artifact、checkpoint、branch/stop 或复用价值的步骤应拆节点或 GX 可见的 bounded fan-out。

## 外部 Job 与 Checkpoint
先持久化 Attempt/submission intent（attempt_id、run_id、node_id、exec_key、capability digest、输入 Artifact digest、资源、idempotency key），Scheduler job name 稳定派生自 attempt_id，再提交后端。GX 重启后按稳定身份对账，不得盲目重提；未知结果保持 OUTCOME_UNKNOWN。Capability 声明 checkpoint_support；续算创建新 Attempt，引用 parent_attempt_id 和 checkpoint Artifact，旧 Attempt 不可变。P2 用故障注入 LocalSchedulerSimulator 验证，Slurm 生产验收后续做。

## Trigger 与部分冻结
表现不佳必须由 Graph 声明 Monitor/Predicate，不能靠 Codex 轮询。Amendment 只冻结受影响 branch；独立 branch 继续。Codex 不可用时受影响 scope 保持 WAITING_DECISION、退避并通知，不终止整个 Run。多 Run 决策排队、合并同 scope 事件、限制并发。

## Goal / Evaluation
Goal Contract 分机械计算标准和科学目标两层。Evaluator 只产出 typed Measurement；GX 按 Goal Contract 判计算验收；湿实验/生物学结论需 Human sign-off。pLDDT、ipTM、界面面积不能自动等同真实结合或活性。

## P2 最小闭环
第二个独立 Plugin（不 import science_grid）自带 Graph Recipe、至少三个可观察 Node、一个新 Capability Manifest、Tool、Evaluator、两个候选 branch 和声明式 Monitor。GX 实例化 GraphVersion、执行 Job、记录 Measurement/Evidence；Codex Decision Session 提议 amendment；GX 校验提交；只重跑受影响 branch；Codex 退出后 GX 继续运行和恢复。建议二维热传导 FTCS vs ADI。

## 非目标
不重写 Codex；不新建 Agent Manager/Scheduler/Job Manager/Budget/Artifact/Event Bus/Workflow Engine；不强搬 science_grid@3；不在 P2 部署完整 Slurm 集群；不自动放宽 Goal。
