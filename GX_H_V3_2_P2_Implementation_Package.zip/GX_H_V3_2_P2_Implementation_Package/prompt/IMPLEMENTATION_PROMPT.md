# Agent Prompt — GX-H v3.2 / P2

你是 GX-H 首席架构与实现工程师。基线预期为 v3.1 HEAD `91ea828a8892d6e2ce125fe89cd5d5a13df18598`。若 checkout 不同，记录准确 commit 并重新审计。

## Mission
在不推翻 v3.1 的情况下，建立通用动态科研 Plugin 基础：GX 持久运行且唯一写权；Codex 按需启动并区分 Decision Session/Agent Task Session；Plugin 自带 Graph Recipe/Node/Tool/Capability/Evaluator；GX 实例化 immutable GraphVersion 并运行；外部 Job 可超越进程生命周期并可对账；Human/PI 拥有 Goal 和硬预算上限。

## 不可违反
- 先审计再改代码。
- 保留 v3.1 terminal protocol、同 Attempt repair、science_grid@3、角色工具范围、Brief Preloading、Native Child scope/recovery。
- 不新建 Agent Manager/Scheduler/Job Manager/Budget/Artifact/Event Bus/Workflow Engine。
- Plugin Graph 是 Recipe；GX 才实例化和执行。
- Decision Session 与 Agent Task Session 分开授权。
- GX 唯一写权；人类控制 Goal 放宽和硬预算增加。
- Evaluator 只输出 Measurement；GX adjudicate；科学结论由人签署。
- Job Attempt-first、稳定身份对账，不得盲目重提。
- 新 seed = 新 exec_key/Attempt。
- 只冻结受影响 branch。
- Mock 不等于真实模型，Local Scheduler 不等于 Slurm 生产验收。

## Phase 0 — Source Audit（不改代码）
产出 `V32_SOURCE_AUDIT.md`：HEAD/dirty state；逐项定位 v3.1 terminal protocol、repair、science_grid@3、roles、Brief、Native Child、Plugin Loader、Workflow Runtime、Jobs/Leases、Budget、Artifact/Evidence/Evaluator；每条 ADR 标记 implemented/partial/missing/conflict/deferred 并附文件行号和证据；区分 Plugin registration 与真正 Graph ownership；确认外部 Job stable identity/checkpoint 现状；说明信任边界。若基线不符先停下报告。

## Phase 1 — ADR Reconciliation
产出 `V32_ADR_DECISIONS.md`。每条决策标 existing/extend/new/deferred。解决现有 schema/API 冲突，避免新增 DB entity；确需新增时提供 migration/rollback。定义两种 Session、Recipe instantiation、Goal/Evaluator、人类签署、Attempt-first Job/checkpoint、semantic key/seed、branch amendment、Codex adapter、Role/Brief。先交审阅，不要直接大规模实现。

## Phase 2 — Deterministic Contract Tests
不调用付费模型：Codex absent 时 GX 继续；Task Session 不能改 Graph；撤销 Lease 拒绝迟到提交；Codex 不能放宽 Goal/加预算；Recipe 默认值展开；Evaluator typed Measurement；隐藏 node loop/unmanaged Job 拒绝；Scheduler 接受后 GX crash 能 reconcile 无重复；checkpoint 新 Attempt lineage；新 seed 新 Attempt；并发 amendment 只有一个 CAS；受影响 branch 冻结、无关 branch 继续；全部 v3.1 回归通过。

## Phase 3 — Independent Graph Plugin
选二维热传导 FTCS vs ADI 或批准的有界数值案例。Plugin 不得 import science_grid。自带 Graph Recipe、至少 3 个可观察 Node、一个新 Capability Manifest（沿用现有格式）、Tool+JSON Schema、Evaluator typed metrics、至少两个候选 branch、声明式 Monitor、显式参数和 Goal ref。用故障注入 LocalSchedulerSimulator。
展示：安装/verify；Human 或 Decision Session 选 Recipe；GX 实例化精确 digest GraphVersion；Attempt 先持久化再 Job submit；执行和测量；Codex Decision Session 提 amendment；GX validate/commit；仅受影响 branch 重跑；Codex 退出后 GX 继续；GX restart 不重复 Job。
不要强行把 science_grid@3 全部搬出核心。

## Phase 4 — 验收
全量回归、v3.1 terminal/repair/native child 专项、新 ADR tests、独立 Artifact/Evidence 核对、同口径性能对照。真实模型调用必须设硬预算并区分 provider-confirmed/estimated。不得把模拟器报告成 Slurm 生产能力。

## 交付
V32_SOURCE_AUDIT.md、V32_ADR_DECISIONS.md、更新的六份 ADR、Acceptance Matrix、独立 Plugin、scheduler simulator/fault tests、implementation report、limitations/next steps、rollback plan、全部命令和原始证据。

## Definition of Done
只有当独立 Plugin 自带 Graph/Nodes/新 Capability；GX 实例化 immutable GraphVersion 并持有全部持久状态；Decision/Task Session 分离；Attempt-first Job reconciliation 故障测试通过；Goal 不可被弱化；Evaluator 不能宣告科学成功；amendment 保留无关 branch；v3.1 回归通过，P2 才可签收。否则如实标 partial。
