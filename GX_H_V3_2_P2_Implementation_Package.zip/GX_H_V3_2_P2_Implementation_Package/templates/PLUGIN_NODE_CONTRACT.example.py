"""Illustrative only; reconcile with actual GX Author API."""
def compute_node(ctx, inputs, parameters):
    return ctx.jobs.request(
        capability_id="org.example.heat-solver",
        capability_version="1.0.0",
        inputs={"grid_artifact": inputs["grid_artifact"],
                "time_horizon": parameters["time_horizon"],
                "seed": parameters.get("random_seed")},
        resources={"cpu": 4, "memory_mb": 4096},
        idempotency_key=ctx.execution.exec_key,
    )

def evaluator_node(ctx, inputs, parameters):
    result = ctx.artifacts.read_json(inputs["observations"])
    return {"measurements": [
        {"metric":"relative_error","value":result["relative_error"],
         "unit":"dimensionless","semantic_class":"numerical_verification","valid":True}],
        "provenance":{"input_digest":inputs["observations_digest"],
                      "evaluator_digest":ctx.plugin.evaluator_digest}}
