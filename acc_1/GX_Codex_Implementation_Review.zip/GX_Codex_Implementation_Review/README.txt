GX + Codex 代码审查交付包

先看 REVIEW.txt。findings.json 方便 Agent 按问题追踪。FIX_AGENT_PROMPT.txt 可交给实现 Agent 修复和补验。

本包是审查结果和诊断代码，不包含产品补丁，也不表示任何问题已修复。
所有源文件路径相对被审查的 gx-h-v2-main 根目录。完整原归档内容未修改。

复现（不调用模型或网络）：
  python -B reproductions/reproduce_durable.py --repo /path/to/gx-h-v2-main
  python -B reproductions/reproduce_intent.py --repo /path/to/gx-h-v2-main

脚本依赖该版本源树自带的测试夹具，不额外安装第三方库。建议用独立工作目录运行。
脚本输出观察状态，退出0仅说明诊断执行完成，不表示产品PASS。修复后应把对应结果转为断言正确行为的回归测试。

原有回归：在原仓库 gx-h 目录执行：
  python -B -m unittest discover -s tests -p 'test_p0_*.py' -v
  python -B -m unittest discover -s tests -v
  python -B adapters/hosts/generate.py --check

当前复验：P0 42/42；全量212项中204通过、4依赖/历史错误、4可选DSH跳过。
本机Codex是0.172.0-alpha.2，与实现锁定0.169.0不同；本次无在线模型、无真实GPU，也没有重新验证历史线上试跑。

全部文件SHA-256在SHA256SUMS中。证据分层、精确位置和修复建议见报告。
