"""Reproduce three durable-execution defects. Emits observed behavior, not a pass certificate.
Uses production GX Python logic, real temporary SQLite, and existing offline protocol fixtures.
The budget contention probe isolates the actual driver loop and actual reservation service;
its two unrelated reactor calls and native transport are controlled doubles.
The lease probe moves the lease expiry clock in the DB; it does not wait two wall-clock hours.
"""
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import argparse
import sys
from pathlib import Path
parser = argparse.ArgumentParser(description="Offline GX code review reproduction; no models or remote jobs.")
parser.add_argument("--repo", type=Path, required=True, help="Unpacked gx-h-v2-main directory, or its gx-h subdirectory")
args = parser.parse_args()
repo = args.repo.expanduser().resolve()
gx = repo / "gx-h" if (repo / "gx-h").is_dir() else repo
if not (gx / "gx_core" / "p0").is_dir():
    parser.error("--repo must contain gx-h/gx_core/p0 or gx_core/p0")
sys.path.insert(0, str(gx))

from gx_core import budgets
from gx_core.errors import BudgetExceeded
from gx_core.p0.driver import Driver, context
from gx_core.p0.cli import run_until_stopped
from gx_core.p0.root_delivery import RootDelivery
from gx_core.persistence import records, store
from gx_core.orchestration import reactor
from tests.test_p0_root_delivery import RootDeliveryTests
from tests.test_p0_roots import DurableRoots

def budget_contention():
    t=RootDeliveryTests()
    t.setUp()
    try:
        conn, run = t.conn, t.run
        conn.execute("UPDATE runs SET status='ACTIVE',inputs_json=? WHERE run_id=?",(json.dumps({'inputs':{'p0':True}}),run))
        b=budgets.create_root(conn,run_id=run,profile_name='p0',actor='test',limits={'tokens':100,'api_calls':10})
        conn.execute('UPDATE runs SET budget_ref=? WHERE run_id=?',(b,run))
        tasks=[]
        for role in ('planner','evidence_reviewer'):
            task=records.create_task(conn,run_id=run,kind='research_round',role=role,actor='test')
            conn.execute("UPDATE tasks SET status='READY' WHERE task_id=?",(task,))
            tasks.append(task)
        trace=[]
        n=SimpleNamespace(conn=conn,run_id=run,token_budget=100,active_turns={})
        delivery=RootDelivery(n)
        def dispatch(tid):
            trace.append('dispatch:'+tid)
            with store.transaction(conn):
                hold,tokens,prior=delivery._reserve('root:'+tid,'start:'+tid)
            n.active_turns['root:'+tid]='turn:'+tid
            return {'turn_id':'turn:'+tid}
        def poll(seconds):
            trace.append('poll:completion-and-settlement-would-be-read-here')
            return False
        n.dispatch=dispatch; n.poll=poll
        d=Driver(conn,Path('/tmp'),run)
        d._native=n
        d.close=lambda:trace.append('driver.close')
        with patch('gx_core.p0.driver.reactor.lazy',return_value=None),patch('gx_core.p0.driver.reactor.drive_science',return_value=None),patch('gx_core.p0.cli.Driver',return_value=d):
            try:run_until_stopped(conn,Path('/tmp'),run,0.3)
            except Exception as e:result={'raised':type(e).__name__,'message':str(e)}
            else:result={'raised':None}
        result.update(trace=trace,active_turns=len(n.active_turns),budget=budgets.state(conn,b))
        return result
    finally:t.doCleanups()

def expired_wait():
    t=DurableRoots();t.setUp()
    try:
        t.roots._request=t.fake
        row=t.bind();conn=t.conn
        conn.execute("INSERT INTO jobs(job_id,run_id,task_id,lease_ref,capability_id,capability_version,status,idempotency_key,submit_intent_json,input_manifest_ref,created_at) VALUES('j',?,?,?,'grid','1','RUNNING','job-key','{}','ref','2026-01-01T00:00:00Z')",(t.run,t.task,row['lease_id']))
        t.roots._park_job(row,'j')
        conn.execute("UPDATE leases SET expires_at='2000-01-01T00:00:00Z' WHERE lease_id=?",(row['lease_id'],))
        # Driver first observes the job terminal, then invokes reactor.lazy -> TeamService.settle.
        conn.execute("UPDATE jobs SET status='SUCCEEDED' WHERE job_id='j'")
        before=dict(conn.execute('SELECT status,attempt,lease_id,attempts_consumed FROM tasks WHERE task_id=?',(t.task,)).fetchone())
        result=reactor.lazy(context(conn), t.run)
        after=dict(conn.execute('SELECT status,attempt,lease_id,attempts_consumed FROM tasks WHERE task_id=?',(t.task,)).fetchone())
        return {'before':before,'after':after,'settle':result,'old_wait_job_id':t.roots._binding(row['thread_id'])['wait_job_id']}
    finally:t.doCleanups()

def missing_usage():
    t=RootDeliveryTests();t.setUp()
    try:
        receipt=t.delivery.deliver('root','work',event_id='run',human=True,message_id='h')
        t.peer.turns[0]['status']='completed'
        t.delivery=RootDelivery(t.peer)
        for _ in range(3):t.delivery.reconcile('root')
        before=t.budget()
        follow=t.delivery.deliver('root','followup',event_id='followup',human=True,message_id='h2')
        t.finish(follow['turn_id'],30)
        return {'after_cold_reconcile':before,'after_followup_with_usage':t.budget(),'turn_usage':[dict(x) for x in t.conn.execute('SELECT * FROM p0_root_turn_usage')]}
    finally:t.doCleanups()

print(json.dumps({'budget_contention':budget_contention(),'expired_wait':expired_wait(),'missing_usage':missing_usage()},indent=2))
