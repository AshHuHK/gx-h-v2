"""Reproduce unread new values, missing item bindings and undelivered supplements.
Uses production GX business functions and a real temporary SQLite DB. No network or model.
Only the temporary filesystem location for a generated Root brief is patched.
"""
import json
from pathlib import Path
from unittest.mock import patch
import argparse
import sys
from pathlib import Path
parser = argparse.ArgumentParser(description="Offline GX code review reproduction; no models or remote jobs.")
parser.add_argument("--repo", type=Path, required=True, help="Unpacked gx-h-v2-main directory, or its gx-h subdirectory")
args = parser.parse_args()
repo = args.repo.expanduser().resolve()
gx = repo / "gx-h" if (repo / "gx-h").is_dir() else repo
if not (gx / "gx_core" / "p0").is_dir():
    parser.error("--repo must contain gx-h/gx_core/p0 or gx_core/p0")
sys.path.insert(0, str(gx))

from tests.test_p0_intent import IntentTests
from gx_core.p0 import intent, science_refresh
from gx_core.p0.roots import Roots, WORKER_TOOLS
from gx_core.persistence import store

import tempfile
probe_directory = tempfile.TemporaryDirectory(prefix="gx-review-intent-")
case = IntentTests()
case.setUp()
try:
    c, rid = case.conn, case.run
    case.change(case.edit('objective','objective',0,'compare two trajectories'),
                case.edit('evaluation','evaluation_spec',0,{'threshold':-0.25}),
                case.edit('format','soft_preference',0,'brief'))
    task, lease = case.task({})
    proposal = {'objective_item':{'item_id':'objective','version':1},
                'evaluation_item':{'item_id':'evaluation','version':1}}
    science_refresh.bind_task(c, rid, task, proposal, 'decision')
    changed = case.change(case.edit('format','soft_preference',1,'explain every result in Chinese'))
    roots = Roots(c, run_id=rid, cwd='/tmp')
    with patch('gx_core.p0.roots.tempfile.gettempdir', return_value=probe_directory.name):
        with store.transaction(c):
            row = roots._new_row(task=c.execute('SELECT * FROM tasks WHERE task_id=?',(task,)).fetchone(), lease=lease, attempt=1)
    first = {'result':changed, 'task_intent_keys':list(intent.snapshot(c,rid,'task',task)),
             'worker_brief_contains_preference': 'explain every result in Chinese' in row['brief']}
    # Even when manually binding a preference as context, the actual notification lacks its new value.
    intent.bind_dependencies(c,rid,'task',task,{'format':'context'})
    before = c.execute('SELECT count(*) FROM outbox').fetchone()[0]
    second = case.change(case.edit('format','soft_preference',2,'include all source citations'))
    notification = json.loads(c.execute("SELECT payload_json FROM outbox WHERE topic='p0.intent.notification' ORDER BY outbox_id DESC LIMIT 1").fetchone()[0])
    second = {'result':second,'delivered_notification_payload':notification,
              'new_value_present': 'include all source citations' in json.dumps(notification),
              'worker_tool_names':[t['name'] for t in WORKER_TOOLS]}
    before = c.execute('SELECT count(*) FROM outbox').fetchone()[0]
    note = case.submit({'kind':'supplement','text':'New measurement: the earlier control was contaminated; reconsider the conclusion.'})
    after = c.execute('SELECT count(*) FROM outbox').fetchone()[0]
    third = {'result':note, 'source_saved':dict(c.execute('SELECT * FROM source_segments WHERE source_id=?',(note['source_id'],)).fetchone()),
             'new_outbox_events':after-before,'task_intent_keys':list(intent.snapshot(c,rid,'task',task)),
             'sources_in_worker_brief':note['source_id'] in row['brief']}
    report = {'audit_mode':'local SQLite and live implementation functions; no model/network used',
              'unbound_preference':first, 'notification_without_value':second, 'supplement_without_delivery':third}
    print(json.dumps(report,ensure_ascii=False,indent=2))
finally:
    case.doCleanups()
    probe_directory.cleanup()
