import json
import sqlite3
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path

sys.path.insert(0,str(Path.cwd()))
from tests.test_v21_workspace_queue import WorkspaceQueueTests
destination=Path(sys.argv[1])
def capture(case):
    folder=destination/case._testMethodName
    folder.mkdir(parents=True)
    db,=Path(tempfile.gettempdir()).rglob("gx.db")
    with closing(sqlite3.connect(db)) as conn,closing(sqlite3.connect(folder/"gx.db")) as output:
        conn.backup(output)
        assert output.execute("PRAGMA integrity_check").fetchone()[0]=="ok"
        output.row_factory=sqlite3.Row
        with (folder/"events.jsonl").open("w") as log:
            for row in output.execute("SELECT * FROM events ORDER BY event_id"):
                print(json.dumps(dict(row)),file=log)
        facts={}
        for key,sql in (("runs","SELECT run_id,status FROM runs ORDER BY rowid"),
                        ("jobs","SELECT run_id,job_id,idempotency_key,status FROM jobs ORDER BY rowid"),
                        ("stage_waits","SELECT run_id,reason,payload_json FROM events WHERE kind='workflow.node_waiting' ORDER BY event_id"),
                        ("human","SELECT run_id,count(*) AS inputs FROM p0_human_inputs GROUP BY run_id")):
            facts[key]=[dict(row) for row in output.execute(sql)]
        (folder/"facts.json").write_text(json.dumps(facts,indent=2)+"\n")
WorkspaceQueueTests.tearDown=capture
suite=unittest.TestSuite(WorkspaceQueueTests(name) for name in (
    "test_partial_start_waits_for_sibling_job_threads_and_reuses_admitted_work",
    "test_cpu_request_larger_than_the_entire_pool_preserves_admission_refusal"))
raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
