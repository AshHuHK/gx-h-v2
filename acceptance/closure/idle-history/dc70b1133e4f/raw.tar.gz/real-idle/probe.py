import json
import os
import sys
import time
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))
from gx_core.p0 import idle
from gx_core.p0.driver import Driver
from tests.test_p2a_idle import IdleBackoff

fixture = IdleBackoff("test_idle01_exponential_cap_and_reset")
fixture.setUp()
wait = idle.WorkspaceWait.wait
samples = []

def timed(listener, seconds, drivers=()):
    started = time.monotonic()
    result = wait(listener, seconds, drivers)
    samples.append({"requested_s": seconds, "blocked_s": time.monotonic() - started,
                    "wake": "timeout" if result == set() else "notification"})
    return result

try:
    started, cpu = time.monotonic(), time.process_time()
    with patch.object(idle.WorkspaceWait, "wait", timed), closing(Driver(fixture.db, fixture.dir, fixture.rid)) as driver:
        result = driver.drive(5)
    wall, used = time.monotonic() - started, time.process_time() - cpu
    print(json.dumps({"status": result["status"], "driver": result["driver"], "wall_s": wall,
                      "process_cpu_s": used, "waits": samples}, indent=2))
    assert result["driver"] == "time_limit"
    assert 1 <= len(samples) <= 8
    assert all(row["wake"] == "timeout" for row in samples)
    assert sum(row["blocked_s"] for row in samples) > 4
    assert used < wall * .5
finally:
    fixture.tearDown()
    fixture.doCleanups()
