"""Negative fixture control. All protocol messages come from the locked host."""
from pathlib import Path
import sys

release, runtime, output = (Path(arg).resolve() for arg in sys.argv[1:])
sys.path[:0] = [str(release / "gx-h"), str(release / "acceptance/v31")]
import terminal_protocol_probe as probe

original = probe.trial_run
def expect_wrong_reason(roots, reader, peer, number, expected, fault, *args, **kwargs):
    if number == 2:
        fault = "lost_raw_cancel"
        probe.CANCELLATION_REASON = "intentionally incorrect required cancellation reason"
    return original(roots, reader, peer, number, expected, fault, *args, **kwargs)

probe.trial_run = expect_wrong_reason
probe.run(1, only="none", closure_usage=True, runtime=runtime, partial_output=output)
