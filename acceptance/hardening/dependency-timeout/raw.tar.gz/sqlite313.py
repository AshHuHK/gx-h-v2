"""Collect the actual 3.13 sqlite ResourceWarning with allocation traces for each sampled fixture."""
import gc, io, json, sqlite3, sys, tracemalloc, unittest, warnings
from pathlib import Path
sys.path[:0] = [str(Path.cwd()), str(Path.cwd() / 'tests')]
ids = [
    'test_p01_metrics.Measurements.test_router_preserves_multiple_snapshots_and_missing_fields',
    'test_p01_metrics.Measurements.test_unwritable_trace_keeps_transaction',
    'test_v31_response_attribution.AttributionTests.test_measured_raw_breakdown_missing_fields_replay_and_single_authoritative_bill',
    'test_web_bridge.WebBridgeTests.test_event_cursor_replays_only_later_project_transitions',
    'test_v21_metering.ThreadAccounts.test_cumulative_includes_cached_input_once_and_regressions_survive_reopen',
]
observations = []
for identity in ids:
    gc.collect()
    stream = io.StringIO()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always', ResourceWarning)
        result = unittest.TextTestRunner(stream=stream).run(unittest.defaultTestLoader.loadTestsFromName(identity))
        gc.collect()
    relevant = [w for w in caught if issubclass(w.category, ResourceWarning) and 'unclosed database' in str(w.message)]
    matches = []
    for warning in relevant:
        frames = tracemalloc.get_object_traceback(warning.source)
        matches.append({'message': str(warning.message), 'emission': [warning.filename,warning.lineno],
                        'allocation': [[frame.filename, frame.lineno] for frame in (frames or [])]})
    observations.append({'id': identity, 'passed': result.wasSuccessful(), 'runner': stream.getvalue(), 'sqlite_warnings': matches})
Path(sys.argv[1]).write_text(json.dumps({'python':sys.version, 'sqlite':sqlite3.sqlite_version,
                            'cases':observations},indent=2)+'\n')
