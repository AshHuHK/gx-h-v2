import gc,json,linecache,sqlite3,sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.path[:0]=[str(Path.cwd()),str(Path.cwd()/'tests')]
tests=['test_p01_metrics','test_v31_response_attribution','test_web_bridge','test_v21_metering']
original=sqlite3.connect
handles=[]
def observed(*args,**kwargs):
 frame=sys._getframe(1)
 file=Path(frame.f_code.co_filename)
 line=linecache.getline(str(file),frame.f_lineno)
 connection=original(*args,**kwargs)
 if file.stem in tests and 'with ' in line and 'sqlite3.connect(' in line:
  handles.append((file.name,frame.f_code.co_name,connection))
 return connection
with patch.object(sqlite3,'connect',observed):
 suite=unittest.defaultTestLoader.loadTestsFromNames(['tests.'+n for n in tests])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
rows=[]
for name,case,conn in handles:
 try: conn.execute('select 1').fetchone(); usable=True
 except sqlite3.ProgrammingError: usable=False
 conn.close()
 rows.append({'file':name,'case':case,'usable_after_fixture_completed':usable})
Path(sys.argv[1]).write_text(json.dumps({'tests':result.testsRun,'passed':result.wasSuccessful(),'scoped_connections':rows},indent=2)+'\n')
