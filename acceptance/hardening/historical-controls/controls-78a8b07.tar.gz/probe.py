"""Run an unedited historical unittest and observe its otherwise discarded diagnostics."""
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

source = Path.cwd()
sys.path.insert(0, str(source))
from gx_core.jobs import capacity

case_name = sys.argv[1]
quota = sys.argv[2]
cases = {
    "jobs": "tests.test_p0_resource_dimensions.ResourceDimensions.test_specific_job_refusal_survives_resume_until_the_project_phase_changes",
    "review": "tests.test_tl1a_review_job.ReviewJob.test_scientific_disagreement_and_unavailable_fit",
}
case = cases[case_name]
original_read = capacity._read


def emit(event, **fields):
    print(json.dumps({"event": event, **fields}, sort_keys=True), flush=True)


def read_cgroup(path):
    if quota != "host" and path == capacity.CGROUP / "cpu.max":
        return f"{int(quota) * 100000} 100000"
    return original_read(path)


def observe(frame, event, value):
    loc = frame.f_locals
    if frame.f_code.co_name == "_threads_or_refuse" and event == "exception":
        _, error, _ = value
        if getattr(error, "code", None) == "RESOURCE_DENIED":
            emit("admission-denial", file=frame.f_code.co_filename, line=frame.f_lineno,
                 code=error.code, message=str(error), details=error.details)
    elif frame.f_code.co_name == "cpu_room" and event == "return" and value:
        emit("cpu-room", **value)
    elif frame.f_code.co_name == "reproduce" and event == "return" and value:
        out = loc["out"] / "checks.json"
        from hashlib import sha256
        emit("review-result", status=value.get("status"), error=value.get("error"), checks=value.get("checks"),
             checks_file_sha256=sha256(out.read_bytes()).hexdigest(), criteria_sha256=sha256((out.parent / "criteria.json").read_bytes()).hexdigest(),
             observations_sha256=sha256((out.parent / "observations.json").read_bytes()).hexdigest())
    elif frame.f_code.co_name == case.rsplit(".", 1)[1] and event == "line" and frame.f_lineno == 52 and case_name == "jobs":
        emit("job-count-before-assertion", count=len(loc["jobs"]), job_ids=[row[0] for row in loc["jobs"]])
    return observe


def tracer(frame, event, value):
    if (frame.f_code.co_filename.endswith(("/gx_core/jobs/service.py", "/gx_core/jobs/capacity.py",
                                         "/tests/test_p0_resource_dimensions.py", "/tests/test_tl1a_review_job.py"))
            and frame.f_code.co_name in {"_threads_or_refuse", "cpu_room", "reproduce", case.rsplit(".", 1)[1]}):
        return observe


def audit(name, args):
    if name == "subprocess.Popen" and any("review_batch.py" in str(item) for item in args[1]):
        emit("review-subprocess", argv=args[1])


emit("environment", case=case, control=quota, actual_cpu_max=original_read(capacity.CGROUP / "cpu.max"),
     python=sys.version.split()[0], executable=sys.executable, cwd=os.getcwd(),
     bio=importlib.util.find_spec("Bio") is not None,
     packages={d.metadata["Name"]:d.version for d in importlib.metadata.distributions()},
     cpu_profile_env=os.getenv("GX_TEST_RESOURCE_PROFILE"))
sys.addaudithook(audit)
suite = unittest.TestLoader().loadTestsFromName(case)
with patch.object(capacity, "_read", read_cgroup):
    sys.settrace(tracer)
    try:
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    finally:
        sys.settrace(None)
sys.exit(0 if result.wasSuccessful() else 1)
