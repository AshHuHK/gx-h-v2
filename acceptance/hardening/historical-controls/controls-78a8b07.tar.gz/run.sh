#!/bin/bash
set -euxo pipefail
base="$(cd "$(dirname "$0")" && pwd)"
cd "$base/checkout"
git rev-parse HEAD
git status --porcelain --untracked-files=normal
/opt/conda/bin/python -I -m venv "$base/venv"
python="$base/venv/bin/python"
"$python" -I -B scripts/release_assets.py cordis
node --version
npm --version
"$python" -I -m pip --isolated --disable-pip-version-check install --no-index --no-cache-dir --no-deps release-assets/python/numpy-*.whl
cd gx-h
function run_case {
    local label=$1
    shift
    local status=0
    "$python" -I -B "$base/probe.py" "$@" >"$base/$label.log" 2>&1 || status=$?
    echo "$label process_exit=$status"
}
run_case review-no-bio review host
"$python" -I -m pip --isolated --disable-pip-version-check install --no-index --no-cache-dir --no-deps ../release-assets/python/biopython-*.whl
run_case review-bio review host
run_case jobs-2cpu jobs 2
run_case jobs-4cpu jobs 4
git status --porcelain --untracked-files=normal
