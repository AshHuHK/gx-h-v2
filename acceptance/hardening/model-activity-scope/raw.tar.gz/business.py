"""Run the unmodified model Activity cases against localhost with unrelated file-lock traffic."""
from concurrent.futures import ThreadPoolExecutor
import fcntl, os, subprocess, sys, tempfile, threading
from pathlib import Path
root, work = map(Path, sys.argv[1:3])
sys.path.insert(0, str(root))
from acceptance.closure.profile import test_environment
work.mkdir()
env = test_environment(work / 'env', python=Path(sys.executable))
gate = threading.Barrier(5)
stop = threading.Event()
def churn():
    with tempfile.TemporaryFile() as fp:
        gate.wait()
        while not stop.is_set():
            for off in range(48):
                fcntl.lockf(fp, fcntl.LOCK_EX, 1, 2*off)
            fcntl.lockf(fp, fcntl.LOCK_UN, 0, 0)
with ThreadPoolExecutor(max_workers=4) as pool:
    work_items = [pool.submit(churn) for _ in range(4)]
    gate.wait()
    try:
        cases = ['tests.test_model_activity.ModelActivityTests.test_lost_reply_blocks_duplicate_request_through_recovery',
                 'tests.test_model_activity.ModelActivityTests.test_receipt_reopens_original_and_budget']
        proc = subprocess.run([sys.executable,'-B','-m','unittest','-v',*(cases*30)],cwd=root/'gx-h',env=env)
    finally:
        stop.set()
    for item in work_items: item.result()
sys.exit(proc.returncode)
