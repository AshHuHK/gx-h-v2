"""Measure a held launcher lock while unrelated temp files acquire/release byte locks."""
from concurrent.futures import ThreadPoolExecutor
import fcntl, json, os, sys, tempfile, threading, time
from pathlib import Path
root = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(root), str(root/'gx-h')]
from acceptance.closure.profile import _scope_for_process
from gx_core.resource_profile import _check_scope
owner = os.getpid()
handle, locator = _scope_for_process(owner)
info = Path(f'/proc/{owner}/fdinfo/{handle.fileno()}')
check = getattr(_check_scope, '__wrapped__', _check_scope)
barrier = threading.Barrier(8)
def load(_):
    with tempfile.TemporaryFile() as fp:
        barrier.wait()
        end = time.monotonic() + 8
        while time.monotonic() < end:
            for off in range(32):
                fcntl.lockf(fp, fcntl.LOCK_EX, 1, off * 2)
            fcntl.lockf(fp, fcntl.LOCK_UN, 0, 0)
def observe(_):
    total, misses, samples = 0, 0, []
    barrier.wait()
    end = time.monotonic() + 8
    while time.monotonic() < end:
        total += 1
        try:
            check(owner, os.getppid(), locator)
        except (ValueError, OSError) as exc:
            misses += 1
            if len(samples) < 3:
                samples.append({'reason': str(exc), 'contemporaneous_fdinfo': info.read_text()})
    return {'checks': total, 'misses': misses, 'samples': samples}
with ThreadPoolExecutor(max_workers=8) as pool:
    loads = [pool.submit(load,i) for i in range(4)]
    checks = [pool.submit(observe,i) for i in range(4)]
    rows = [f.result() for f in checks]
    for future in loads:
        future.result()
Path(sys.argv[2]).write_text(json.dumps({'locator':locator, 'final_fdinfo':info.read_text(), 'readers':rows,
                                         'total_checks':sum(r['checks'] for r in rows),
                                         'total_misses':sum(r['misses'] for r in rows)}, indent=2)+'\n')
