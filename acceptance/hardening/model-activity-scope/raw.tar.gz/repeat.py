from pathlib import Path
import os,subprocess,sys,json
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from acceptance.closure.profile import test_environment
folder=Path(sys.argv[1]);folder.mkdir()
env=test_environment(folder/'env',python=Path(sys.executable))
process=subprocess.run([sys.executable,'-B','-m','unittest','-v',
       *(['tests.test_model_activity.ModelActivityTests.test_lost_reply_blocks_duplicate_request_through_recovery',
        'tests.test_model_activity.ModelActivityTests.test_receipt_reopens_original_and_budget']*30)],
      cwd=root/'gx-h',env=env)
sys.exit(process.returncode)
