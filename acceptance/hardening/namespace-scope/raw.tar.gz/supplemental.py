import os,sys,subprocess
from pathlib import Path
stage,work,clash=map(Path,sys.argv[1:])
work.mkdir()
sys.path.insert(0,str(stage))
from acceptance.closure.profile import test_environment
python=stage/'.venv/bin/python'
env=test_environment(work/'private',python=python)
cmd=[python,'-B',stage/'acceptance/phase2a/regression/loopback.py','--clash',clash,'--receipt',work/'network.json',
     '--',python,'-B',stage/'acceptance/phase2a/regression/standalone_child.py','--stage',stage,'--out',work/'result']
sys.exit(subprocess.call(cmd,cwd=stage,env=env))
