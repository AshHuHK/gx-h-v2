"""Read the kernel scope before and after a real loopback-only user-namespace transition."""
import argparse, json, os, subprocess, sys
from pathlib import Path

def main():
    root, work, clash = map(Path,sys.argv[1:4])
    sys.path[:0] = [str(root),str(root/'gx-h')]
    if sys.argv[4] == 'inner':
        from gx_core.resource_profile import deterministic_test_resources
        marker = os.environ.get('GX_ACCEPTANCE_RESOURCE_SCOPE')
        outer = os.environ.get('GX_TOPOLOGY_OUTER_LOCATOR')
        def inspect(locator):
            if not locator:
                return None
            pid, fd, _ = locator.split('/')
            try:
                return {'record': Path(f'/proc/{pid}/fdinfo/{fd}').read_text()}
            except OSError as exc:
                return {'errno':exc.errno, 'type':type(exc).__name__}
        result = {'uid':os.getuid(),'uid_map':Path('/proc/self/uid_map').read_text().strip(),
                  'fixture_scope':marker, 'fixture_fdinfo':inspect(marker),'outer_fdinfo':inspect(outer),
                  'controlled':deterministic_test_resources(),'userns':os.readlink('/proc/self/ns/user')}
        print(json.dumps(result))
        return
    from acceptance.closure.profile import test_environment
    summary={'outer_uid':os.getuid(),'outer_uid_map':Path('/proc/self/uid_map').read_text().strip()}
    for label in ('controlled','real','invalid'):
        env=test_environment(work/('env-'+label),profile='real' if label=='real' else 'deterministic',python=Path(sys.executable))
        if label=='invalid':
            env['GX_ACCEPTANCE_RESOURCE_SCOPE']='invalid'
        elif label=='controlled':
            env['GX_TOPOLOGY_OUTER_LOCATOR']=env['GX_ACCEPTANCE_RESOURCE_SCOPE']
        network=work/(label+'-network.json')
        argv=[sys.executable,'-B',root/'acceptance/phase2a/regression/loopback.py','--clash',clash,'--receipt',network,'--',
              sys.executable,'-B',Path(__file__),root,work,clash,'inner']
        run=subprocess.run(argv,env=env,cwd=root,text=True,capture_output=True)
        (work/(label+'.log')).write_text(run.stdout+run.stderr)
        if label=='invalid':
            assert run.returncode!=0 and 'ResourceProfileError' in run.stderr and not network.exists()
            summary[label]={'exit':run.returncode,'pre_unshare_refusal':True}
        else:
            assert run.returncode==0,(run.stdout,run.stderr)
            obs=json.loads(run.stdout)
            info=json.loads(network.read_text())
            assert obs['controlled']==(label=='controlled')
            assert info['outer_user_namespace']!=obs['userns']==info['fixture_user_namespace']
            assert info['fixture_uid_map'].split()==['0',str(summary['outer_uid']),'1']
            if label=='controlled':
                assert info['outer_scope']!=obs['fixture_scope']==info['fixture_scope'] and 'lock:' in obs['fixture_fdinfo']['record']
            else:
                assert info['fixture_scope'] is None and obs['fixture_scope'] is None
            summary[label]={'exit':0,**obs}
    (work/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
if __name__=='__main__':
    main()
