from contextlib import closing
import json, os, sqlite3, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from gx_core.p0.idle import WorkspaceWait
from gx_core.persistence import store

writer = """from gx_core.persistence import store
import sys,time
from contextlib import closing
with closing(store.connect(sys.argv[1])) as conn:
    print("ready",flush=True)
    sys.stdin.readline()
    time.sleep(.05)
    with store.transaction(conn):
        conn.execute("INSERT INTO observed VALUES(1)")
        store.on_transaction_end(conn,on_commit=lambda: print(time.monotonic(),flush=True))
"""
with tempfile.TemporaryDirectory() as tmp, closing(store.connect(Path(tmp)/"gx.db")) as conn:
    conn.execute("CREATE TABLE observed(value INTEGER)")
    with WorkspaceWait(conn) as wait:
        original=os.fstat(wait.fd).st_ino
        wait.path.unlink()
        os.mkfifo(wait.path,0o600)
        newer=wait.path.stat().st_ino
        assert original != newer
        with subprocess.Popen([sys.executable,"-B","-c",writer,str(Path(tmp)/"gx.db")],
                              stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True) as child:
            assert child.stdout.readline().strip()=="ready"
            child.stdin.write("commit\n")
            child.stdin.flush()
            wake=wait.wait(1)
            returned=time.monotonic()
            committed=float(child.stdout.readline())
            assert child.wait(timeout=5)==0
        assert conn.execute("SELECT count(*) FROM observed").fetchone()[0]==1
        print(json.dumps({"open_inode":original,"replacement_inode":newer,"writer_pid":child.pid,
              "reader_pid":os.getpid(),"woke_on_commit":wake is None,"commit_to_return_s":returned-committed,
              "requested_wait_s":1}))
